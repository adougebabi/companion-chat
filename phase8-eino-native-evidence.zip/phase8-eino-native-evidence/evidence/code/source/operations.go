package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

func (a *App) RevokeAll(ctx context.Context, actorID string) error {
	_, err := a.DB.Pool().Exec(ctx, `UPDATE public.auth_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE human_actor_id=$1`, actorID)
	a.authAudit(ctx, "revoke_all", actorID, auditResult(err), "")
	return err
}

func (a *App) RevokeCurrent(ctx context.Context, actorID, token string) error {
	if strings.TrimSpace(token) == "" {
		a.authAudit(ctx, "revoke_current", actorID, "failed", "token_invalid")
		return ErrUnauthorized
	}
	command, err := a.DB.Pool().Exec(ctx, `UPDATE public.auth_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE human_actor_id=$1 AND token_hash=$2`, actorID, digestToken(token))
	if err != nil {
		a.authAudit(ctx, "revoke_current", actorID, "failed", "persistence_failure")
		return err
	}
	if command.RowsAffected() == 0 {
		a.authAudit(ctx, "revoke_current", actorID, "failed", "session_not_found")
		return ErrUnauthorized
	}
	a.authAudit(ctx, "revoke_current", actorID, "success", "")
	return nil
}

func (a *App) ResetPassword(ctx context.Context, actorID, password string) error {
	if len(password) < 6 {
		a.authAudit(ctx, "reset_password", actorID, "failed", "password_invalid")
		return errors.New("password_invalid")
	}
	hash, err := hashArgon2ID(password)
	if err != nil {
		return err
	}
	err = withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		command, err := tx.Exec(ctx, `UPDATE public.owner_accounts SET credential_hash=$2,credential_revision=$3,updated_at=now() WHERE human_actor_id=$1`, actorID, hash, randomID("credential_"))
		if err != nil {
			return err
		}
		if command.RowsAffected() != 1 {
			return ErrUnauthorized
		}
		_, err = tx.Exec(ctx, `UPDATE public.auth_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE human_actor_id=$1`, actorID)
		return err
	})
	a.authAudit(ctx, "reset_password", actorID, auditResult(err), "")
	return err
}

func auditResult(err error) string {
	if err != nil {
		return "failed"
	}
	return "success"
}

func (a *App) CreateConversation(ctx context.Context, ownerID string, participants []any, title string) (map[string]any, error) {
	if len(participants) == 0 {
		return nil, errors.New("conversation_participants_required")
	}
	conversationID := randomID("conversation_")
	ids := make([]string, 0, len(participants)+1)
	ids = append(ids, ownerID)
	for _, raw := range participants {
		if id := stringValue(raw); id != "" && id != ownerID {
			ids = append(ids, id)
		}
	}
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		for _, id := range ids[1:] {
			var actorType, createdBy string
			if err := tx.QueryRow(ctx, `SELECT a.actor_type,COALESCE(f.created_by_actor_id,'') FROM public.actors a LEFT JOIN public.fluctlights f ON f.id=a.id WHERE a.id=$1`, id).Scan(&actorType, &createdBy); err != nil {
				if errors.Is(err, pgx.ErrNoRows) {
					return ErrNotFound
				}
				return err
			}
			if actorType == "fluctlight" && createdBy != ownerID {
				return ErrUnauthorized
			}
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.conversations(id,created_by_actor_id,title,revision) VALUES($1,$2,$3,0)`, conversationID, ownerID, nullableString(title)); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.conversation_heads(conversation_id,next_sequence) VALUES($1,1)`, conversationID); err != nil {
			return err
		}
		for i, id := range ids {
			role := "member"
			if i == 0 {
				role = "owner"
			}
			if _, err := tx.Exec(ctx, `INSERT INTO public.conversation_participants(conversation_id,actor_id,role,status) VALUES($1,$2,$3,'active') ON CONFLICT DO NOTHING`, conversationID, id, role); err != nil {
				return err
			}
			if _, err := tx.Exec(ctx, `INSERT INTO public.conversation_read_positions(conversation_id,actor_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, conversationID, id); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	page, err := a.DB.History(ctx, conversationID, ownerID, nil, 50)
	if err != nil {
		return nil, err
	}
	return map[string]any{"id": conversationID, "conversation": page.Conversation, "participants": page.Participants, "messages": page.Messages}, nil
}

func (a *App) MarkRead(ctx context.Context, actorID, conversationID string, payload map[string]any) error {
	read := intValue(payload["read_sequence"])
	delivered := intValue(payload["delivered_sequence"])
	if read < 0 || delivered < 0 || delivered < read {
		return errors.New("conversation_read_position_invalid")
	}
	command, err := a.DB.Pool().Exec(ctx, `UPDATE public.conversation_read_positions SET last_read_sequence=GREATEST(last_read_sequence,$3),last_delivered_sequence=GREATEST(last_delivered_sequence,$4),updated_at=now() WHERE conversation_id=$1 AND actor_id=$2`, conversationID, actorID, read, delivered)
	if err != nil {
		return err
	}
	if command.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

func (a *App) SetFluctlightStatus(ctx context.Context, actorID, id, status, reason string, expected *int) (map[string]any, error) {
	if status != "active" && status != "paused" {
		return nil, errors.New("status_invalid")
	}
	return a.setFluctlightLifecycle(ctx, actorID, id, status, reason, expected)
}

func (a *App) RetireFluctlight(ctx context.Context, actorID, id, reason string, expected *int) (map[string]any, error) {
	return a.setFluctlightLifecycle(ctx, actorID, id, "retired", reason, expected)
}

func (a *App) setFluctlightLifecycle(ctx context.Context, actorID, id, status, reason string, expected *int) (map[string]any, error) {
	if strings.TrimSpace(reason) == "" || len([]rune(reason)) > 1024 {
		return nil, errors.New("fluctlight_reason_invalid")
	}
	if expected == nil {
		return nil, errors.New("expected_revision_required")
	}
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		var currentRevision, lifecycleRevision int
		var currentStatus, owner string
		var retiredAt *time.Time
		if err := tx.QueryRow(ctx, `SELECT created_by_actor_id,status,current_revision,lifecycle_revision,retired_at FROM public.fluctlights WHERE id=$1 FOR UPDATE`, id).Scan(&owner, &currentStatus, &currentRevision, &lifecycleRevision, &retiredAt); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		if owner != actorID {
			return ErrUnauthorized
		}
		if currentStatus == "retired" && status != "retired" {
			return errors.New("fluctlight_retired")
		}
		// The public contract's expected_revision is the Fluctlight aggregate
		// revision exposed by detail.current_revision. Lifecycle transitions do
		// not create a foundation revision, so compare against that value while
		// retaining a separate lifecycle audit counter.
		if expected != nil && *expected != currentRevision {
			return ErrConflict
		}
		if currentStatus == status {
			result = map[string]any{"id": id, "status": currentStatus, "revision": lifecycleRevision, "current_revision": currentRevision, "reason": reason}
			if retiredAt != nil {
				result["retired_at"] = retiredAt.Format(time.RFC3339Nano)
			}
			return nil
		}
		lifecycleRevision++
		if err := tx.QueryRow(ctx, `UPDATE public.fluctlights SET status=$2::varchar,lifecycle_revision=$3,retired_at=CASE WHEN $2::varchar='retired' THEN COALESCE(retired_at,now()) ELSE retired_at END,updated_at=now() WHERE id=$1 RETURNING retired_at`, id, status, lifecycleRevision).Scan(&retiredAt); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.fluctlight_governance(id,fluctlight_id,revision,from_status,to_status,actor_id,reason) VALUES($1,$2,$3,$4,$5,$6,$7)`, randomID("fluctlight_governance_"), id, lifecycleRevision, currentStatus, status, actorID, nullableString(reason)); err != nil {
			return err
		}
		result = map[string]any{"id": id, "status": status, "revision": lifecycleRevision, "current_revision": currentRevision, "reason": reason}
		if retiredAt != nil {
			result["retired_at"] = retiredAt.Format(time.RFC3339Nano)
		}
		return nil
	})
	if err == nil && status == "active" {
		_, ensureErr := a.EnsureWakeUpIntents(ctx)
		if ensureErr == nil {
			_, ensureErr = a.releaseWakeUpIntent(ctx, id, "fluctlight_activated")
		}
		if ensureErr != nil {
			correlationID := fmt.Sprintf("lifecycle:%s:revision:%d", id, intValue(result["revision"]))
			slog.Warn("Go Core Fluctlight activation could not rearm WakeUp",
				"fluctlight_id", id,
				"correlation_id", correlationID,
				"error_type", fmt.Sprintf("%T", ensureErr),
			)
			a.RecordLifecycleDiagnosticBestEffort(ctx, LifecycleDiagnostic{
				Surface: "wake_up", Transition: LifecycleTransitionFailed, Severity: "error",
				FluctlightID: id, CorrelationID: correlationID,
				IntentID: "wake_up_intent:" + id, WorkflowID: "wake_up:" + id,
				Stage: "lifecycle_rearm", Status: "failed",
				ReasonCode: "wake_up_rearm_failed", ErrorCategory: "persistence",
				ErrorCode: "wake_up_rearm_failed", Retryable: true,
			})
		}
	}
	return result, err
}

func (a *App) ProposeFoundation(ctx context.Context, actorID, fluctlightID string, payload map[string]any) (map[string]any, error) {
	f, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID)
	if err != nil {
		return nil, err
	}
	changes := mapValue(payload["changes"])
	if len(changes) == 0 {
		return nil, errors.New("foundation_changes_invalid")
	}
	if err := validateFoundationChanges(changes); err != nil {
		return nil, err
	}
	var current int
	var initializationMode, lifecycleStatus string
	var foundationCreatedAt time.Time
	if err := a.DB.Pool().QueryRow(ctx, `SELECT current_revision,initialization_mode,status,created_at FROM public.fluctlights WHERE id=$1 AND created_by_actor_id=$2`, fluctlightID, actorID).Scan(&current, &initializationMode, &lifecycleStatus, &foundationCreatedAt); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}
	if raw, ok := payload["expected_revision"]; !ok || raw == nil {
		return nil, errors.New("expected_revision_required")
	} else if intValue(raw) != current {
		return nil, ErrConflict
	}
	candidate := map[string]any{
		"identity":          mergeFoundationMap(f.Identity, mapValue(changes["identity"])),
		"personality":       mergeFoundationMap(f.Personality, mapValue(changes["personality"])),
		"behavioral_policy": mergeFoundationMap(f.BehavioralPolicy, mapValue(changes["behavioral_policy"])),
		"life_profile":      mergeFoundationMap(f.LifeProfile, mapValue(changes["life_profile"])),
		"provenance":        mergeFoundationMap(f.Provenance, mapValue(changes["provenance"])),
	}
	corePersona := mergeFoundationMap(f.CorePersona, map[string]any{
		"identity":          candidate["identity"],
		"personality":       candidate["personality"],
		"behavioral_policy": candidate["behavioral_policy"],
		"life_profile":      candidate["life_profile"],
	})
	if _, ok := corePersona["schema_version"]; !ok {
		corePersona["schema_version"] = 1
	}
	identityPatch := make(map[string]any)
	for key, value := range changes {
		if _, known := map[string]struct{}{"name": {}, "age": {}, "gender": {}, "occupation": {}, "residence": {}, "timezone": {}, "birthday": {}, "background": {}, "biography": {}, "core_values": {}, "worldview": {}, "notes": {}}[key]; known {
			identityPatch[key] = value
		}
	}
	if len(identityPatch) > 0 {
		candidate["identity"] = mergeFoundationMap(candidate["identity"].(map[string]any), identityPatch)
	}
	if value, ok := changes["identity"].(map[string]any); ok && len(value) > 0 {
		candidate["identity"] = mergeFoundationMap(f.Identity, value)
	}
	corePersona["identity"] = candidate["identity"]
	corePersona["personality"] = candidate["personality"]
	corePersona["behavioral_policy"] = candidate["behavioral_policy"]
	corePersona["life_profile"] = candidate["life_profile"]
	candidate["core_persona"] = corePersona
	id := randomID("foundation_revision_")
	err = withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		evidence := arrayValue(payload["evidence_refs"])
		if len(evidence) == 0 {
			evidence = []any{"owner:" + actorID}
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.fluctlight_foundation_revisions(id,fluctlight_id,revision,base_revision,source,status,actor_id,initialization_mode,foundation_status,foundation_created_at,confidence,changes,core_persona,identity,personality,behavioral_policy,life_profile,provenance,evidence_refs,reason,idempotency_key) VALUES($1,$2,$3,$4,'human','proposed',$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)`, id, fluctlightID, current+1, current, actorID, initializationMode, lifecycleStatus, foundationCreatedAt, jsonBytes(1.0), jsonBytes(changes), jsonBytes(candidate["core_persona"]), jsonBytes(candidate["identity"]), jsonBytes(candidate["personality"]), jsonBytes(candidate["behavioral_policy"]), jsonBytes(candidate["life_profile"]), jsonBytes(candidate["provenance"]), jsonBytes(evidence), stringValue(payload["reason"]), "foundation:"+id); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO public.fluctlight_foundation_governance(id,fluctlight_id,revision_id,action,actor_id,reason) VALUES($1,$2,$3,'propose',$4,$5)`, randomID("foundation_governance_"), fluctlightID, id, actorID, nullableString(stringValue(payload["reason"])))
		return err
	})
	if err != nil {
		return nil, err
	}
	return map[string]any{"id": id, "fluctlight_id": fluctlightID, "revision": current + 1, "base_revision": current, "status": "proposed", "changes": changes, "core_persona": candidate["core_persona"], "identity": candidate["identity"], "personality": candidate["personality"], "behavioral_policy": candidate["behavioral_policy"], "life_profile": candidate["life_profile"], "provenance": candidate["provenance"]}, nil
}

func (a *App) SetFoundationDecision(ctx context.Context, actorID, fluctlightID, revisionID, action, reason string) (map[string]any, error) {
	return a.SetFoundationDecisionExpected(ctx, actorID, fluctlightID, revisionID, action, reason, nil)
}

func (a *App) SetFoundationDecisionExpected(ctx context.Context, actorID, fluctlightID, revisionID, action, reason string, expected *int) (map[string]any, error) {
	if action != "accept" && action != "reject" {
		return nil, errors.New("foundation_decision_invalid")
	}
	if strings.TrimSpace(reason) == "" || len([]rune(reason)) > 1024 {
		return nil, errors.New("foundation_reason_invalid")
	}
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := lockLifeContextTx(ctx, tx, fluctlightID); err != nil {
			return err
		}
		var revision, baseRevision int
		var status, storedReason string
		var corePersona, identity, personality, policy, life, provenance []byte
		if err := tx.QueryRow(ctx, `SELECT revision,base_revision,status,core_persona,identity,personality,behavioral_policy,life_profile,provenance,COALESCE(reason,'') FROM public.fluctlight_foundation_revisions WHERE id=$1 AND fluctlight_id=$2 AND actor_id=$3 FOR UPDATE`, revisionID, fluctlightID, actorID).Scan(&revision, &baseRevision, &status, &corePersona, &identity, &personality, &policy, &life, &provenance, &storedReason); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		if status != "proposed" {
			if status == action+"ed" && storedReason == reason {
				result = map[string]any{"id": revisionID, "fluctlight_id": fluctlightID, "revision": revision, "status": status, "reason": reason, "replayed": true}
				return nil
			}
			if status == action+"ed" {
				return errors.New("foundation_decision_idempotency_conflict")
			}
			return errors.New("foundation_revision_not_proposed")
		}
		var current int
		var lifecycleStatus string
		var currentIdentity []byte
		if err := tx.QueryRow(ctx, `SELECT current_revision,status,identity FROM public.fluctlights WHERE id=$1 AND created_by_actor_id=$2 FOR UPDATE`, fluctlightID, actorID).Scan(&current, &lifecycleStatus, &currentIdentity); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		if expected != nil && current != *expected {
			return ErrConflict
		}
		if action == "accept" {
			if current != baseRevision {
				return ErrConflict
			}
			if expected != nil && current != *expected {
				return ErrConflict
			}
			if _, err := tx.Exec(ctx, `UPDATE public.fluctlight_foundation_revisions SET status='accepted',foundation_status=$2,accepted_at=now(),reason=$3 WHERE id=$1`, revisionID, lifecycleStatus, nullableString(reason)); err != nil {
				return err
			}
			if len(decodeObject(corePersona)) == 0 {
				var currentCore []byte
				if err := tx.QueryRow(ctx, `SELECT core_persona FROM public.fluctlights WHERE id=$1`, fluctlightID).Scan(&currentCore); err != nil {
					return err
				}
				fallback := map[string]any{"schema_version": 1, "identity": decodeObject(identity), "personality": decodeObject(personality), "behavioral_policy": decodeObject(policy), "life_profile": decodeObject(life)}
				if system := mapValue(decodeObject(currentCore)["personality_system"]); len(system) > 0 {
					fallback["personality_system"] = system
				}
				corePersona = jsonBytes(fallback)
			}
			if _, err := tx.Exec(ctx, `UPDATE public.fluctlights SET current_revision=$2,core_persona=$3,identity=$4,personality=$5,behavioral_policy=$6,life_profile=$7,provenance=$8,updated_at=now() WHERE id=$1`, fluctlightID, revision, corePersona, identity, personality, policy, life, provenance); err != nil {
				return err
			}
			if err := a.applyLifeContextTimezoneChangeTx(ctx, tx, fluctlightID, actorID, revisionID, revision, decodeObject(currentIdentity), decodeObject(identity)); err != nil {
				return err
			}
		} else if _, err := tx.Exec(ctx, `UPDATE public.fluctlight_foundation_revisions SET status='rejected',foundation_status=$2,rejected_at=now(),reason=$3 WHERE id=$1`, revisionID, lifecycleStatus, nullableString(reason)); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.fluctlight_foundation_governance(id,fluctlight_id,revision_id,action,actor_id,reason) VALUES($1,$2,$3,$4,$5,$6)`, randomID("foundation_governance_"), fluctlightID, revisionID, action, actorID, nullableString(reason)); err != nil {
			return err
		}
		result = map[string]any{"id": revisionID, "fluctlight_id": fluctlightID, "revision": revision, "status": action + "ed", "reason": reason, "replayed": false}
		return nil
	})
	return result, err
}

func (a *App) RollbackFoundation(ctx context.Context, actorID, fluctlightID string, payload map[string]any) (map[string]any, error) {
	target, ok := nonNegativeRevision(payload["target_revision"])
	if !ok {
		return nil, errors.New("target_revision_invalid")
	}
	reason := stringValue(payload["reason"])
	if reason == "" || len([]rune(reason)) > 1024 {
		return nil, errors.New("foundation_reason_invalid")
	}
	expected, expectedOK := nonNegativeRevision(payload["expected_revision"])
	if !expectedOK {
		return nil, errors.New("expected_revision_invalid")
	}
	var result map[string]any
	idempotencyKey := "foundation-rollback:" + fluctlightID + ":" + fmt.Sprint(target) + ":" + fmt.Sprint(expected)
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := lockLifeContextTx(ctx, tx, fluctlightID); err != nil {
			return err
		}
		var replayID, replayStatus, replayReason, replayActor string
		var replayRevision, replayBase int
		var replayChanges []byte
		if replayErr := tx.QueryRow(ctx, `SELECT id,revision,base_revision,status,actor_id,COALESCE(reason,''),changes FROM public.fluctlight_foundation_revisions WHERE idempotency_key=$1 FOR UPDATE`, idempotencyKey).Scan(&replayID, &replayRevision, &replayBase, &replayStatus, &replayActor, &replayReason, &replayChanges); replayErr == nil {
			if replayStatus != "accepted" || replayActor != actorID || replayReason != reason || replayBase != expected || intValue(decodeObject(replayChanges)["rollback_from_revision"]) != target {
				return errors.New("foundation_rollback_idempotency_conflict")
			}
			result = map[string]any{"id": replayID, "fluctlight_id": fluctlightID, "revision": replayRevision, "target_revision": target, "status": "accepted", "reason": reason, "replayed": true}
			return nil
		} else if !errors.Is(replayErr, pgx.ErrNoRows) {
			return replayErr
		}
		var current int
		var currentIdentity []byte
		if err := tx.QueryRow(ctx, `SELECT current_revision,identity FROM public.fluctlights WHERE id=$1 AND created_by_actor_id=$2 FOR UPDATE`, fluctlightID, actorID).Scan(&current, &currentIdentity); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		if current != expected {
			return ErrConflict
		}
		if target >= current {
			return errors.New("target_revision_invalid")
		}
		var sourceID, sourceStatus string
		var corePersona, identity, personality, policy, life, provenance, evidence []byte
		if err := tx.QueryRow(ctx, `SELECT id,status,core_persona,identity,personality,behavioral_policy,life_profile,provenance,evidence_refs FROM public.fluctlight_foundation_revisions WHERE fluctlight_id=$1 AND revision=$2`, fluctlightID, target).Scan(&sourceID, &sourceStatus, &corePersona, &identity, &personality, &policy, &life, &provenance, &evidence); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		if sourceStatus != "accepted" {
			return errors.New("foundation_target_not_accepted")
		}
		newRevision := current + 1
		newID := randomID("foundation_revision_")
		if _, err := tx.Exec(ctx, `INSERT INTO public.fluctlight_foundation_revisions(id,fluctlight_id,revision,base_revision,source,status,actor_id,initialization_mode,foundation_status,foundation_created_at,confidence,changes,core_persona,identity,personality,behavioral_policy,life_profile,provenance,evidence_refs,reason,idempotency_key) SELECT $1,fluctlight_id,$2,$3,'owner_rollback','accepted',$4,initialization_mode,'active',foundation_created_at,confidence,jsonb_build_object('rollback_from_revision',$5),core_persona,identity,personality,behavioral_policy,life_profile,provenance,evidence_refs,$6,$7 FROM public.fluctlight_foundation_revisions WHERE id=$8`, newID, newRevision, current, actorID, target, nullableString(reason), idempotencyKey, sourceID); err != nil {
			return err
		}
		if len(decodeObject(corePersona)) == 0 {
			var currentCore []byte
			if err := tx.QueryRow(ctx, `SELECT core_persona FROM public.fluctlights WHERE id=$1`, fluctlightID).Scan(&currentCore); err != nil {
				return err
			}
			fallback := map[string]any{"schema_version": 1, "identity": decodeObject(identity), "personality": decodeObject(personality), "behavioral_policy": decodeObject(policy), "life_profile": decodeObject(life)}
			if system := mapValue(decodeObject(currentCore)["personality_system"]); len(system) > 0 {
				fallback["personality_system"] = system
			}
			corePersona = jsonBytes(fallback)
		}
		if _, err := tx.Exec(ctx, `UPDATE public.fluctlights SET current_revision=$2,core_persona=$3,identity=$4,personality=$5,behavioral_policy=$6,life_profile=$7,provenance=$8,updated_at=now() WHERE id=$1`, fluctlightID, newRevision, corePersona, identity, personality, policy, life, provenance); err != nil {
			return err
		}
		if err := a.applyLifeContextTimezoneChangeTx(ctx, tx, fluctlightID, actorID, newID, newRevision, decodeObject(currentIdentity), decodeObject(identity)); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.fluctlight_foundation_governance(id,fluctlight_id,revision_id,action,actor_id,reason) VALUES($1,$2,$3,'rollback',$4,$5)`, randomID("foundation_governance_"), fluctlightID, newID, actorID, nullableString(reason)); err != nil {
			return err
		}
		result = map[string]any{"id": newID, "fluctlight_id": fluctlightID, "revision": newRevision, "target_revision": target, "status": "accepted", "reason": reason, "replayed": false}
		_ = evidence
		return nil
	})
	return result, err
}

func positiveRevision(value any) (int, bool) {
	parsed := intValue(value)
	return parsed, parsed > 0
}

func mergeFoundationMap(base, changes map[string]any) map[string]any {
	result := make(map[string]any, len(base)+len(changes))
	for key, value := range base {
		result[key] = value
	}
	for key, value := range changes {
		if nested, ok := value.(map[string]any); ok {
			if existing, ok := result[key].(map[string]any); ok {
				result[key] = mergeFoundationMap(existing, nested)
				continue
			}
		}
		result[key] = value
	}
	return result
}

func validateFoundationChanges(changes map[string]any) error {
	for key, value := range changes {
		switch key {
		case "identity", "personality", "behavioral_policy", "life_profile":
			if _, ok := value.(map[string]any); !ok {
				return errors.New("foundation_changes_invalid")
			}
		case "provenance":
			provenance, ok := value.(map[string]any)
			if !ok {
				return errors.New("foundation_changes_invalid")
			}
			if _, forbidden := provenance["self_model"]; forbidden {
				return errors.New("foundation_self_model_forbidden")
			}
		case "id", "initialization_mode", "status", "current_revision", "created_at":
			return errors.New("foundation_field_immutable")
		default:
			if _, known := map[string]struct{}{"name": {}, "age": {}, "gender": {}, "occupation": {}, "residence": {}, "timezone": {}, "birthday": {}, "background": {}, "biography": {}, "core_values": {}, "worldview": {}, "notes": {}}[key]; !known {
				return errors.New("foundation_field_invalid")
			}
		}
	}
	return nil
}

func (a *App) ReviseMemory(ctx context.Context, actorID, id, content string, expected *int, refs []any) (map[string]any, error) {
	if strings.TrimSpace(content) == "" || len([]rune(content)) > 32000 || len(refs) == 0 || expected == nil {
		return nil, errors.New("memory_revision_invalid")
	}
	evidenceRefs, err := ownerMemoryEvidence(refs)
	if err != nil {
		return nil, err
	}
	row, _, err := a.readOwnedMemoryRevisionSnapshot(ctx, actorID, id, *expected)
	if err != nil {
		return nil, err
	}
	semantic := &MemorySemanticInput{Type: row.Type, Content: strings.TrimSpace(content), Confidence: row.Confidence, Importance: row.Importance, EmotionalSignificance: row.EmotionalSignificance}
	command := buildOwnerMemoryCommand(row, actorID, MemoryRevise, *expected, evidenceRefs, semantic, "owner_memory_revise", nil, nil)
	result, err := a.applyOwnerMemoryCommand(ctx, command)
	if err != nil {
		return nil, err
	}
	return memoryApplyResultMap(result), nil
}

func (a *App) ForgetMemory(ctx context.Context, actorID, id string, expected *int, refs []any) (map[string]any, error) {
	if len(refs) == 0 || expected == nil {
		return nil, errors.New("memory_forget_invalid")
	}
	evidenceRefs, err := ownerMemoryEvidence(refs)
	if err != nil {
		return nil, err
	}
	row, _, err := a.readOwnedMemoryRevisionSnapshot(ctx, actorID, id, *expected)
	if err != nil {
		return nil, err
	}
	command := buildOwnerMemoryCommand(row, actorID, MemoryForget, *expected, evidenceRefs, nil, "owner_memory_forget", nil, nil)
	result, err := a.applyOwnerMemoryCommand(ctx, command)
	if err != nil {
		return nil, err
	}
	return memoryApplyResultMap(result), nil
}

func (a *App) GovernAutonomy(ctx context.Context, actorID, actionID, toStatus, reason string) (map[string]any, error) {
	if toStatus != "paused" && toStatus != "cancelled" && toStatus != "failed" && toStatus != "frozen" {
		return nil, errors.New("autonomy_status_invalid")
	}
	var fluctlightID, from, workflowID, actionType string
	var rawPayload []byte
	if err := a.DB.Pool().QueryRow(ctx, `SELECT fluctlight_id,status,workflow_id,action_type,payload FROM public.autonomy_actions WHERE id=$1`, actionID).Scan(&fluctlightID, &from, &workflowID, &actionType, &rawPayload); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return nil, ErrUnauthorized
	}
	if err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		command, err := tx.Exec(ctx, `UPDATE public.autonomy_actions SET status=$2::varchar,error_code=CASE WHEN $2::varchar='failed' THEN $3 ELSE error_code END,settled_at=CASE WHEN $2::varchar IN ('failed','cancelled') THEN now() ELSE settled_at END WHERE id=$1 AND status=$4`, actionID, toStatus, reason, from)
		if err != nil {
			return err
		}
		if command.RowsAffected() != 1 {
			return errors.New("autonomy_status_stale")
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.autonomy_governance(id,fluctlight_id,action_id,from_status,to_status,actor_id,reason) VALUES($1,$2,$3,$4,$5,$6,$7)`, randomID("autonomy_governance_"), fluctlightID, actionID, from, toStatus, actorID, reason); err != nil {
			return err
		}
		if toStatus == "failed" || toStatus == "cancelled" {
			payload := decodeObject(rawPayload)
			causality, err := frozenDecisionCausality(payload)
			if err != nil {
				return err
			}
			settlement := map[string]any{"status": toStatus, "action_status": toStatus, "reason": reason}
			if toStatus == "failed" {
				settlement["error_code"] = firstString(reason, "autonomy_governed_failed")
			}
			for key, value := range causality {
				settlement[key] = value
			}
			results, resultsErr := capabilityResultsFromValue(payload["capability_results"])
			if resultsErr != nil {
				results = nil
				settlement["reason_code"] = "capability_results_invalid"
			}
			outcomes, outcomeErr := buildActionOutcomes(actionID, fluctlightID, firstString(payload["source_fact_id"], actionID), actionType, results, settlement, a.capabilityRegistry())
			if outcomeErr != nil {
				outcomes, outcomeErr = buildActionOutcomes(actionID, fluctlightID, firstString(payload["source_fact_id"], actionID), actionType, nil, settlement, a.capabilityRegistry())
			}
			if outcomeErr != nil {
				return outcomeErr
			}
			if err := persistActionOutcomesTx(ctx, tx, outcomes); err != nil {
				return err
			}
			factPayload := map[string]any{"action_id": actionID, "result": settlement, "outcomes": outcomes}
			factID, err := appendProcessedCognitionFactTx(ctx, tx, fluctlightID, "autonomy.result", factPayload, "action-result:"+actionID)
			if err != nil {
				return err
			}
			if err := insertReflectionIntentTx(ctx, tx,
				"reflection_intent:result:"+actionID,
				"reflection:result:"+actionID,
				map[string]any{"fluctlight_id": fluctlightID, "source_fact_id": factID, "action_id": actionID},
			); err != nil {
				return err
			}
		}
		return appendOutboxTx(ctx, tx, "autonomy.governed", "autonomy_action", actionID, fluctlightID, actorID, "autonomy:"+actionID, "autonomy-governance:"+actionID+":"+toStatus, map[string]any{"from_status": from, "to_status": toStatus})
	}); err != nil {
		return nil, err
	}
	result := map[string]any{"id": actionID, "status": toStatus, "from_status": from, "reason": reason}
	if (toStatus == "cancelled" || toStatus == "paused") && strings.TrimSpace(workflowID) != "" && a.Workflows != nil {
		command := "cancel"
		if toStatus == "paused" {
			command = "pause"
		}
		if workflowResult, workflowErr := a.WorkflowCommand(ctx, actorID, workflowID, command, map[string]any{"action_id": actionID, "reason": reason}); workflowErr != nil {
			result["workflow_command_error"] = workflowErr.Error()
		} else {
			result["workflow_command"] = workflowResult
		}
	}
	return result, nil
}

func nullableString(value string) any {
	if strings.TrimSpace(value) == "" {
		return nil
	}
	return value
}

func (a *App) ConfigureProviderRole(ctx context.Context, actorID string, payload map[string]any) error {
	if _, err := a.ReadSettings(ctx, actorID); err != nil {
		return err
	}
	role, endpoint, model := stringValue(payload["role"]), stringValue(payload["endpoint_id"]), stringValue(payload["model_id"])
	if !validProviderRole(role) || endpoint == "" || model == "" {
		return errors.New("provider_role_invalid")
	}
	bindingRole := providerBindingRole(role)
	budget := intValue(payload["token_budget"])
	timeout := intValue(payload["timeout_seconds"])
	if budget <= 0 {
		budget = 4096
	}
	if timeout <= 0 {
		timeout = 120
	}
	contextWindowTokens := 0
	maxInputTokens := 0
	promptBudgetPolicyVersion := ""
	_ = a.DB.Pool().QueryRow(ctx, `SELECT context_window_tokens,max_input_tokens,prompt_budget_policy_version FROM public.model_roles WHERE role=$1`, bindingRole).Scan(&contextWindowTokens, &maxInputTokens, &promptBudgetPolicyVersion)
	contextWindowExplicit := false
	if raw, present := payload["context_window_tokens"]; present {
		contextWindowTokens = intValue(raw)
		contextWindowExplicit = true
		if contextWindowTokens <= 0 {
			return errors.New("provider_prompt_budget_invalid")
		}
	} else if contextWindowTokens < defaultContextWindowTokens {
		contextWindowTokens = defaultContextWindowTokens
	}
	maxInputExplicit := false
	if raw, present := payload["max_input_tokens"]; present {
		maxInputTokens = intValue(raw)
		maxInputExplicit = true
		if maxInputTokens <= 0 {
			return errors.New("provider_prompt_budget_invalid")
		}
	} else if maxInputTokens < defaultMaxInputTokens {
		maxInputTokens = defaultMaxInputTokens
	}
	if raw, present := payload["prompt_budget_policy_version"]; present {
		promptBudgetPolicyVersion = strings.TrimSpace(stringValue(raw))
		if promptBudgetPolicyVersion == "" {
			return errors.New("prompt_budget_policy_unknown")
		}
	} else if strings.TrimSpace(promptBudgetPolicyVersion) == "" {
		promptBudgetPolicyVersion = promptBudgetPolicyVersionV1
	}
	margin, err := promptSafetyMargin(promptBudgetPolicyVersion)
	if err != nil {
		return err
	}
	if !contextWindowExplicit && !maxInputExplicit {
		if maxInputTokens+budget+margin > contextWindowTokens {
			if contextWindowTokens-budget-margin >= 32768 {
				maxInputTokens = contextWindowTokens - budget - margin
			} else {
				contextWindowTokens = maxInputTokens + budget + margin
			}
		}
	} else if !contextWindowExplicit {
		if maxInputTokens+budget+margin > contextWindowTokens {
			contextWindowTokens = maxInputTokens + budget + margin
		}
	} else if !maxInputExplicit {
		if maxInputTokens+budget+margin > contextWindowTokens && contextWindowTokens-budget-margin > 0 {
			maxInputTokens = contextWindowTokens - budget - margin
		}
	}
	if err := validatePromptBudgetConfiguration(contextWindowTokens, maxInputTokens, budget, promptBudgetPolicyVersion); err != nil {
		return err
	}
	var endpointExists bool
	if err := a.DB.Pool().QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM public.provider_endpoints WHERE id=$1)`, endpoint).Scan(&endpointExists); err != nil {
		return err
	}
	if !endpointExists {
		return errors.New("provider_endpoint_not_found")
	}
	models, err := a.ProviderModels(ctx, actorID, endpoint)
	if err != nil {
		return fmt.Errorf("provider_models_unavailable: %w", err)
	}
	modelAvailable := false
	for _, raw := range arrayValue(models["models"]) {
		if stringValue(raw) == model {
			modelAvailable = true
			break
		}
	}
	if !modelAvailable {
		return errors.New("provider_model_not_available")
	}
	return withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `INSERT INTO public.model_roles(role,provider_endpoint_id,model_id,token_budget,timeout_seconds,required_capabilities,retry_policy,context_window_tokens,max_input_tokens,prompt_budget_policy_version) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(role) DO UPDATE SET provider_endpoint_id=excluded.provider_endpoint_id,model_id=excluded.model_id,token_budget=excluded.token_budget,timeout_seconds=excluded.timeout_seconds,required_capabilities=excluded.required_capabilities,retry_policy=excluded.retry_policy,context_window_tokens=excluded.context_window_tokens,max_input_tokens=excluded.max_input_tokens,prompt_budget_policy_version=excluded.prompt_budget_policy_version`, bindingRole, endpoint, model, budget, timeout, stringValue(payload["required_capabilities"]), jsonString(mapValue(payload["retry_policy"])), contextWindowTokens, maxInputTokens, promptBudgetPolicyVersion); err != nil {
			return err
		}
		preflightID := "provider_preflight_" + stableDigest(bindingRole+":"+endpoint+":"+model)
		if _, err := tx.Exec(ctx, `INSERT INTO public.provider_preflights(id,role,result,capability_version,checked_at) VALUES($1,$2,'available',$3,now()) ON CONFLICT(id) DO UPDATE SET result='available',capability_version=excluded.capability_version,checked_at=now()`, preflightID, bindingRole, "models-v1"); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `UPDATE public.provider_endpoints SET capability_status='available',checked_at=now() WHERE id=$1`, endpoint)
		return err
	})
}

func (a *App) ActorGroups(ctx context.Context, owner string) ([]map[string]any, error) {
	rows, err := a.DB.Pool().Query(ctx, `SELECT id,name,created_at FROM public.actor_groups WHERE owner_actor_id=$1 ORDER BY created_at,id`, owner)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id, name string
		var created time.Time
		if err := rows.Scan(&id, &name, &created); err != nil {
			return nil, err
		}
		members := make([]string, 0)
		mrows, e := a.DB.Pool().Query(ctx, `SELECT actor_id FROM public.actor_group_members WHERE group_id=$1 ORDER BY actor_id`, id)
		if e != nil {
			return nil, e
		}
		for mrows.Next() {
			var m string
			_ = mrows.Scan(&m)
			members = append(members, m)
		}
		mrows.Close()
		out = append(out, map[string]any{"id": id, "name": name, "owner_actor_id": owner, "actor_ids": members, "created_at": created.Format(time.RFC3339Nano)})
	}
	return out, rows.Err()
}
func (a *App) CreateActorGroup(ctx context.Context, owner, name string) (map[string]any, error) {
	if strings.TrimSpace(name) == "" || len([]rune(name)) > 60 {
		return nil, errors.New("actor_group_name_invalid")
	}
	id := randomID("actor_group_")
	_, err := a.DB.Pool().Exec(ctx, `INSERT INTO public.actor_groups(id,owner_actor_id,name) VALUES($1,$2,$3)`, id, owner, name)
	if err != nil {
		return nil, err
	}
	return map[string]any{"id": id, "name": name, "owner_actor_id": owner, "actor_ids": []string{}}, nil
}
func (a *App) SetActorGroupMember(ctx context.Context, owner, groupID, actorID string, add bool) error {
	var groupOwner string
	if err := a.DB.Pool().QueryRow(ctx, `SELECT owner_actor_id FROM public.actor_groups WHERE id=$1`, groupID).Scan(&groupOwner); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return ErrNotFound
		}
		return err
	}
	if groupOwner != owner {
		return ErrUnauthorized
	}
	if add {
		_, err := a.DB.Pool().Exec(ctx, `INSERT INTO public.actor_group_members(group_id,actor_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, groupID, actorID)
		return err
	}
	_, err := a.DB.Pool().Exec(ctx, `DELETE FROM public.actor_group_members WHERE group_id=$1 AND actor_id=$2`, groupID, actorID)
	return err
}

func (a *App) RollbackRelationship(ctx context.Context, actorID, fluctlightID string, payload map[string]any) (map[string]any, error) {
	target := stringValue(payload["target_actor_id"])
	if target == "" {
		return nil, errors.New("relationship_target_invalid")
	}
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return nil, ErrUnauthorized
	}
	expected, ok := nonNegativeRevision(payload["expected_revision"])
	if !ok {
		return nil, errors.New("relationship_expected_revision_invalid")
	}
	targetRevision, ok := nonNegativeRevision(payload["target_revision"])
	if !ok {
		return nil, errors.New("relationship_target_revision_invalid")
	}
	evidence := arrayValue(payload["evidence_refs"])
	if len(evidence) == 0 {
		return nil, errors.New("relationship_evidence_required")
	}
	profileID := strings.TrimSpace(stringValue(payload["profile_id"]))
	if profileID == "" {
		_ = a.DB.Pool().QueryRow(ctx, `SELECT COALESCE(active_profile_id,'default') FROM public.fluctlight_personality_runtime WHERE fluctlight_id=$1`, fluctlightID).Scan(&profileID)
		if profileID == "" {
			profileID = "default"
		}
	}
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		var id string
		var storedProfileID *string
		var revision int
		var role, metrics, emotional, provenance []byte
		var trend string
		var summary *string
		if err := tx.QueryRow(ctx, `SELECT id,profile_id,revision,role,metrics,trend,summary,emotional_association,provenance FROM public.relationships WHERE owner_fluctlight_id=$1 AND target_actor_id=$2 AND (profile_id=$3 OR profile_id IS NULL) ORDER BY CASE WHEN profile_id=$3 THEN 0 ELSE 1 END LIMIT 1 FOR UPDATE`, fluctlightID, target, profileID).Scan(&id, &storedProfileID, &revision, &role, &metrics, &trend, &summary, &emotional, &provenance); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		if revision != expected {
			return ErrConflict
		}
		var sourceRevision int
		var sourceRole, sourceMetrics, sourceEmotional []byte
		var sourceTrend string
		var sourceSummary *string
		if err := tx.QueryRow(ctx, `SELECT revision,role,metrics,trend,summary,emotional_association FROM public.relationship_revisions WHERE relationship_id=$1 AND revision=$2`, id, targetRevision).Scan(&sourceRevision, &sourceRole, &sourceMetrics, &sourceTrend, &sourceSummary, &sourceEmotional); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrNotFound
			}
			return err
		}
		newRevision := revision + 1
		refs := append(append([]any{}, evidence...), "rollback:"+fmt.Sprint(targetRevision))
		rollbackProvenance := map[string]any{"source": "manual", "action": "rollback", "actor_id": actorID, "evidence_refs": refs}
		if _, err := tx.Exec(ctx, `UPDATE public.relationships SET role=$2,metrics=$3,trend=$4,summary=$5,emotional_association=$6,provenance=$7,revision=$8,updated_at=now() WHERE id=$1 AND revision=$9`, id, sourceRole, sourceMetrics, sourceTrend, sourceSummary, sourceEmotional, jsonBytes(rollbackProvenance), newRevision, expected); err != nil {
			return err
		}
		newRevisionID := randomID("relationship_revision_")
		if _, err := tx.Exec(ctx, `INSERT INTO public.relationship_revisions(id,relationship_id,revision,base_revision,role,metrics,trend,summary,emotional_association,evidence_refs,actor_id,idempotency_key) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, newRevisionID, id, newRevision, expected, sourceRole, sourceMetrics, sourceTrend, sourceSummary, sourceEmotional, jsonBytes(refs), actorID, "relationship-rollback:"+id+":"+fmt.Sprint(targetRevision)+":"+fmt.Sprint(expected)); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO public.relationship_governance(id,relationship_id,revision_id,action,actor_id,reason) VALUES($1,$2,$3,'rollback',$4,$5)`, randomID("relationship_governance_"), id, newRevisionID, actorID, nullableString(stringValue(payload["reason"]))); err != nil {
			return err
		}
		result = map[string]any{"id": id, "relationship_id": id, "profile_id": profileID, "revision": newRevision, "target_revision": sourceRevision, "status": "rolled_back"}
		if storedProfileID != nil && strings.TrimSpace(*storedProfileID) != "" {
			result["profile_id"] = *storedProfileID
		}
		_ = role
		_ = metrics
		_ = emotional
		_ = provenance
		return nil
	})
	return result, err
}

func nonNegativeRevision(value any) (int, bool) {
	parsed := intValue(value)
	return parsed, parsed >= 0
}

func (a *App) CreateLifeEvent(ctx context.Context, actorID, fluctlightID string, payload map[string]any) (map[string]any, error) {
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return nil, err
	}
	start, e1 := parseScheduleTime(stringValue(payload["start_at"]))
	end, e2 := parseScheduleTime(stringValue(payload["end_at"]))
	if e1 != nil || e2 != nil || !end.After(start) {
		return nil, errors.New("life_event_time_invalid")
	}
	refs := arrayValue(payload["evidence_refs"])
	if len(refs) == 0 {
		return nil, errors.New("life_event_evidence_required")
	}
	idempotency := strings.TrimSpace(stringValue(payload["idempotency_key"]))
	if idempotency == "" || len([]rune(idempotency)) > 256 {
		return nil, errors.New("life_event_idempotency_key_required")
	}
	expectedLifeRevision := strings.TrimSpace(stringValue(payload["expected_life_context_revision"]))
	if expectedLifeRevision == "" {
		return nil, errors.New("life_context_revision_required")
	}
	id := "event_" + stableDigest(fluctlightID+":"+idempotency)
	requestDigest := stableDigest(jsonString(map[string]any{
		"fluctlight_id": fluctlightID, "kind": stringValue(payload["kind"]), "start_at": start.UTC().Format(time.RFC3339Nano),
		"end_at": end.UTC().Format(time.RFC3339Nano), "scene": stringValue(payload["scene"]), "activity": stringValue(payload["activity"]),
		"location": stringValue(payload["location"]), "evidence_refs": refs, "idempotency_key": idempotency,
		"expected_life_context_revision": expectedLifeRevision,
	}))
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := lockLifeContextTx(ctx, tx, fluctlightID); err != nil {
			return err
		}
		var existingID, existingDigest string
		var existingResult []byte
		if replayErr := tx.QueryRow(ctx, `SELECT id,COALESCE(request_digest,''),result FROM public.life_events WHERE fluctlight_id=$1 AND idempotency_key=$2 FOR UPDATE`, fluctlightID, idempotency).Scan(&existingID, &existingDigest, &existingResult); replayErr == nil {
			if existingDigest != requestDigest {
				return errors.New("life_event_idempotency_conflict")
			}
			result = decodeObject(existingResult)
			if len(result) == 0 {
				return errors.New("life_event_replay_result_invalid")
			}
			id = existingID
			result["replayed"] = true
			return nil
		} else if !errors.Is(replayErr, pgx.ErrNoRows) {
			return replayErr
		}
		applyAt := time.Now().UTC()
		if _, err := a.requireLifeContextRevisionTx(ctx, tx, fluctlightID, expectedLifeRevision, applyAt); err != nil {
			return err
		}
		inserted, err := tx.Exec(ctx, `INSERT INTO public.life_events(id,fluctlight_id,kind,start_at,end_at,scene,activity,location,status,revision,evidence_refs,idempotency_key,request_digest,result) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'confirmed',1,$9,$10,$11,'{}')`, id, fluctlightID, stringValue(payload["kind"]), start, end, nullableString(stringValue(payload["scene"])), nullableString(stringValue(payload["activity"])), nullableString(stringValue(payload["location"])), jsonBytes(refs), idempotency, requestDigest)
		if err != nil {
			return err
		}
		if inserted.RowsAffected() != 1 {
			return ErrConflict
		}
		_, resultingLife, err := resolveLifeContextSnapshotWith(ctx, tx, fluctlightID, applyAt)
		if err != nil {
			return err
		}
		inboxID, err := a.enqueueNativeFactTx(ctx, tx, fluctlightID, stringValue(payload["conversation_id"]), "owner:"+actorID, "life.event.created", "life-event:"+stableDigest(fluctlightID+"\x1f"+idempotency), map[string]any{"event_id": id, "kind": stringValue(payload["kind"]), "expected_context_revision": expectedLifeRevision, "resulting_context_revision": resultingLife["context_revision"]})
		if err != nil {
			return err
		}
		result = map[string]any{
			"id": id, "fluctlight_id": fluctlightID, "status": "confirmed", "revision": 1,
			"idempotency_key": idempotency, "inbox_id": inboxID, "expected_context_revision": expectedLifeRevision,
			"resulting_context_revision": resultingLife["context_revision"], "replayed": false,
		}
		if _, err := tx.Exec(ctx, `UPDATE public.life_events SET result=$2 WHERE id=$1 AND revision=1`, id, jsonBytes(result)); err != nil {
			return err
		}
		return appendOutboxTx(ctx, tx, "life.event.created", "fluctlight", fluctlightID, fluctlightID, actorID, "life:"+id, "life-event:"+fluctlightID+":"+stableDigest(idempotency), map[string]any{"event_id": id, "revision": 1, "aggregate_sequence": 1})
	})
	if err != nil {
		return nil, err
	}
	return result, nil
}
func (a *App) CancelLifeEvent(ctx context.Context, actorID, fluctlightID, eventID string, payload map[string]any) (map[string]any, error) {
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return nil, err
	}
	expectedEventRevision, ok := positiveRevision(payload["expected_event_revision"])
	if !ok {
		return nil, errors.New("life_event_revision_required")
	}
	expectedLifeRevision := strings.TrimSpace(stringValue(payload["expected_life_context_revision"]))
	if expectedLifeRevision == "" {
		return nil, errors.New("life_context_revision_required")
	}
	idempotency := strings.TrimSpace(stringValue(payload["idempotency_key"]))
	if idempotency == "" || len([]rune(idempotency)) > 256 {
		return nil, errors.New("life_event_cancel_idempotency_key_required")
	}
	requestDigest := stableDigest(jsonString(map[string]any{
		"fluctlight_id": fluctlightID, "event_id": eventID, "expected_event_revision": expectedEventRevision,
		"expected_life_context_revision": expectedLifeRevision, "idempotency_key": idempotency,
	}))
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := lockLifeContextTx(ctx, tx, fluctlightID); err != nil {
			return err
		}
		if replay, found, err := lifeContextCommandResultTx(ctx, tx, fluctlightID, "event.cancel", eventID, idempotency, requestDigest, "life_event_cancel_idempotency_conflict"); err != nil {
			return err
		} else if found {
			result = replay
			return nil
		}
		applyAt := time.Now().UTC()
		if _, err := a.requireLifeContextRevisionTx(ctx, tx, fluctlightID, expectedLifeRevision, applyAt); err != nil {
			return err
		}
		var resultingEventRevision int
		if err := tx.QueryRow(ctx, `UPDATE public.life_events SET status='cancelled',revision=revision+1,updated_at=$4 WHERE id=$1 AND fluctlight_id=$2 AND status <> 'cancelled' AND revision=$3 RETURNING revision`, eventID, fluctlightID, expectedEventRevision, applyAt).Scan(&resultingEventRevision); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrConflict
			}
			return err
		}
		_, resultingLife, err := resolveLifeContextSnapshotWith(ctx, tx, fluctlightID, applyAt)
		if err != nil {
			return err
		}
		inboxID, err := a.enqueueNativeFactTx(ctx, tx, fluctlightID, "", eventID, "life.event.cancelled", "life-cancel:"+stableDigest(fluctlightID+"\x1f"+idempotency), map[string]any{"event_id": eventID, "revision": resultingEventRevision, "expected_context_revision": expectedLifeRevision, "resulting_context_revision": resultingLife["context_revision"]})
		if err != nil {
			return err
		}
		result = map[string]any{
			"id": eventID, "fluctlight_id": fluctlightID, "status": "cancelled", "revision": resultingEventRevision,
			"idempotency_key": idempotency, "inbox_id": inboxID, "expected_context_revision": expectedLifeRevision,
			"resulting_context_revision": resultingLife["context_revision"], "replayed": false,
		}
		if err := storeLifeContextCommandResultTx(ctx, tx, fluctlightID, "event.cancel", eventID, idempotency, requestDigest, result); err != nil {
			return err
		}
		return appendOutboxTx(ctx, tx, "life.event.cancelled", "fluctlight", fluctlightID, fluctlightID, eventID, "life:"+eventID, "life-cancel:"+fluctlightID+":"+stableDigest(idempotency), map[string]any{"event_id": eventID, "aggregate_sequence": resultingEventRevision})
	})
	return result, err
}
func (a *App) SetPresence(ctx context.Context, actorID, fluctlightID string, payload map[string]any) (map[string]any, error) {
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return nil, err
	}
	if stringValue(payload["scene"]) != "" || stringValue(payload["activity"]) != "" || stringValue(payload["location"]) != "" {
		return nil, errors.New("presence_overlay_cannot_replace_scene")
	}
	idempotency := strings.TrimSpace(stringValue(payload["idempotency_key"]))
	if idempotency == "" || len([]rune(idempotency)) > 256 {
		return nil, errors.New("presence_idempotency_key_required")
	}
	expectedLifeRevision := strings.TrimSpace(stringValue(payload["expected_life_context_revision"]))
	if expectedLifeRevision == "" {
		return nil, errors.New("life_context_revision_required")
	}
	id := "presence_overlay_" + stableDigest(fluctlightID+":"+idempotency)
	var requestedExpiry *time.Time
	if raw := stringValue(payload["expires_at"]); raw != "" {
		parsed, err := time.Parse(time.RFC3339, raw)
		if err != nil {
			return nil, errors.New("presence_expiration_invalid")
		}
		parsed = parsed.UTC()
		requestedExpiry = &parsed
	}
	currentTask := nullableString(stringValue(payload["current_task"]))
	userPresence := nullableString(stringValue(payload["user_presence"]))
	if currentTask == nil && userPresence == nil {
		return nil, errors.New("presence_overlay_fields_required")
	}
	requestDigest := stableDigest(jsonString(map[string]any{"fluctlight_id": fluctlightID, "actor_id": actorID, "current_task": currentTask, "user_presence": userPresence, "requested_expires_at": requestedExpiry, "idempotency_key": idempotency, "expected_life_context_revision": expectedLifeRevision}))
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := lockLifeContextTx(ctx, tx, fluctlightID); err != nil {
			return err
		}
		var existingDigest string
		var existingResult []byte
		if replayErr := tx.QueryRow(ctx, `SELECT COALESCE(request_digest,''),result FROM public.life_presence_overlays WHERE fluctlight_id=$1 AND idempotency_key=$2 FOR UPDATE`, fluctlightID, idempotency).Scan(&existingDigest, &existingResult); replayErr == nil {
			if existingDigest != requestDigest {
				return errors.New("presence_idempotency_conflict")
			}
			result = decodeObject(existingResult)
			if len(result) == 0 {
				return errors.New("presence_replay_result_invalid")
			}
			result["replayed"] = true
			return nil
		} else if !errors.Is(replayErr, pgx.ErrNoRows) {
			return replayErr
		}
		applyAt := time.Now().UTC()
		expiresAt := applyAt.Add(presenceDefaultDuration)
		if requestedExpiry != nil {
			expiresAt = requestedExpiry.UTC()
		}
		if !expiresAt.After(applyAt) || expiresAt.After(applyAt.Add(presenceMaxDuration)) {
			return errors.New("presence_expiration_invalid")
		}
		if _, err := a.requireLifeContextRevisionTx(ctx, tx, fluctlightID, expectedLifeRevision, applyAt); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE public.life_presence_overlays SET status='superseded',revision=revision+1,superseded_by_overlay_id=$2,updated_at=$3 WHERE fluctlight_id=$1 AND status='active'`, fluctlightID, id, applyAt); err != nil {
			return err
		}
		inserted, err := tx.Exec(ctx, `INSERT INTO public.life_presence_overlays(id,fluctlight_id,actor_id,scene,activity,location,current_task,user_presence,status,revision,idempotency_key,request_digest,result,expires_at,created_at,updated_at) VALUES($1,$2,$3,NULL,NULL,NULL,$4,$5,'active',1,$6,$7,'{}',$8,$9,$9)`, id, fluctlightID, actorID, currentTask, userPresence, idempotency, requestDigest, expiresAt, applyAt)
		if err != nil {
			return err
		}
		if inserted.RowsAffected() != 1 {
			return ErrConflict
		}
		_, resultingLife, err := resolveLifeContextSnapshotWith(ctx, tx, fluctlightID, applyAt)
		if err != nil {
			return err
		}
		inboxID, err := a.enqueueNativeFactTx(ctx, tx, fluctlightID, "", "owner:"+actorID, "life.presence.updated", "presence:"+stableDigest(fluctlightID+"\x1f"+idempotency), map[string]any{"overlay_id": id, "current_task": stringValue(payload["current_task"]), "user_presence": stringValue(payload["user_presence"]), "expected_context_revision": expectedLifeRevision, "resulting_context_revision": resultingLife["context_revision"]})
		if err != nil {
			return err
		}
		result = map[string]any{
			"id": id, "fluctlight_id": fluctlightID, "actor_id": actorID, "current_task": payload["current_task"],
			"user_presence": payload["user_presence"], "expires_at": expiresAt.Format(time.RFC3339Nano), "revision": 1,
			"status":          "active",
			"idempotency_key": idempotency, "inbox_id": inboxID, "expected_context_revision": expectedLifeRevision,
			"resulting_context_revision": resultingLife["context_revision"], "replayed": false,
		}
		if _, err := tx.Exec(ctx, `UPDATE public.life_presence_overlays SET result=$2 WHERE id=$1 AND revision=1`, id, jsonBytes(result)); err != nil {
			return err
		}
		return appendOutboxTx(ctx, tx, "life.presence.updated", "fluctlight", fluctlightID, fluctlightID, actorID, "presence:"+id, "presence:"+fluctlightID+":"+stableDigest(idempotency), map[string]any{"overlay_id": id, "revision": 1, "aggregate_sequence": 1})
	})
	if err != nil {
		return nil, err
	}
	return result, nil
}
func (a *App) CancelScheduleExpected(ctx context.Context, actorID, fluctlightID, scheduleID string, payload map[string]any) (map[string]any, error) {
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return nil, err
	}
	expectedScheduleRevision, ok := positiveRevision(payload["expected_revision"])
	if !ok {
		return nil, errors.New("schedule_revision_required")
	}
	expectedLifeRevision := strings.TrimSpace(stringValue(payload["expected_life_context_revision"]))
	if expectedLifeRevision == "" {
		return nil, errors.New("life_context_revision_required")
	}
	idempotency := strings.TrimSpace(stringValue(payload["idempotency_key"]))
	if idempotency == "" || len([]rune(idempotency)) > 256 {
		return nil, errors.New("schedule_cancel_idempotency_key_required")
	}
	requestDigest := stableDigest(jsonString(map[string]any{
		"fluctlight_id": fluctlightID, "schedule_id": scheduleID, "expected_revision": expectedScheduleRevision,
		"expected_life_context_revision": expectedLifeRevision, "idempotency_key": idempotency,
	}))
	var result map[string]any
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := lockLifeContextTx(ctx, tx, fluctlightID); err != nil {
			return err
		}
		if replay, found, err := lifeContextCommandResultTx(ctx, tx, fluctlightID, "schedule.cancel", scheduleID, idempotency, requestDigest, "schedule_cancel_idempotency_conflict"); err != nil {
			return err
		} else if found {
			result = replay
			return nil
		}
		applyAt := time.Now().UTC()
		if _, err := a.requireLifeContextRevisionTx(ctx, tx, fluctlightID, expectedLifeRevision, applyAt); err != nil {
			return err
		}
		var resultingScheduleRevision int
		if err := tx.QueryRow(ctx, `UPDATE public.life_schedules SET status='cancelled',revision=revision+1,updated_at=$4 WHERE id=$1 AND fluctlight_id=$2 AND status='accepted' AND revision=$3 RETURNING revision`, scheduleID, fluctlightID, expectedScheduleRevision, applyAt).Scan(&resultingScheduleRevision); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return ErrConflict
			}
			return err
		}
		_, resultingLife, err := resolveLifeContextSnapshotWith(ctx, tx, fluctlightID, applyAt)
		if err != nil {
			return err
		}
		result = map[string]any{
			"id": scheduleID, "fluctlight_id": fluctlightID, "status": "cancelled", "revision": resultingScheduleRevision,
			"idempotency_key": idempotency, "expected_context_revision": expectedLifeRevision,
			"resulting_context_revision": resultingLife["context_revision"], "replayed": false,
		}
		if err := storeLifeContextCommandResultTx(ctx, tx, fluctlightID, "schedule.cancel", scheduleID, idempotency, requestDigest, result); err != nil {
			return err
		}
		return appendOutboxTx(ctx, tx, "schedule.cancelled", "fluctlight", fluctlightID, scheduleID, scheduleID, "schedule:"+scheduleID, "schedule-cancel:"+fluctlightID+":"+stableDigest(idempotency), map[string]any{"schedule_id": scheduleID, "aggregate_sequence": resultingScheduleRevision})
	})
	return result, err
}

func (a *App) AllMoments(ctx context.Context, actorID string, includeHidden bool, limit int) ([]map[string]any, error) {
	if limit < 1 {
		limit = 100
	}
	if limit > 200 {
		limit = 200
	}
	query := `SELECT m.id,m.owner_fluctlight_id,m.author_actor_id,m.text,m.visibility,m.status,m.media_asset_ids,m.created_at
		FROM public.moments m
		JOIN public.fluctlights f ON f.id=m.owner_fluctlight_id
		WHERE f.created_by_actor_id=$1 AND f.status<>'retired' AND m.visibility IN ('owner','participants')`
	if !includeHidden {
		query += ` AND m.status<>'hidden'`
	}
	query += ` ORDER BY m.created_at DESC,m.id DESC LIMIT $2`
	rows, err := a.DB.Pool().Query(ctx, query, actorID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id, owner, author, text, visibility, status string
		var media []byte
		var created time.Time
		if err := rows.Scan(&id, &owner, &author, &text, &visibility, &status, &media, &created); err != nil {
			return nil, err
		}
		moment := map[string]any{"id": id, "owner_fluctlight_id": owner, "author_actor_id": author, "text": text, "visibility": visibility, "status": status, "media_asset_ids": decodeArray(media), "created_at": created.Format(time.RFC3339Nano)}
		if err := a.hydrateMoment(ctx, actorID, moment); err != nil {
			return nil, err
		}
		out = append(out, moment)
	}
	return out, rows.Err()
}
func (a *App) MarkMomentsRead(ctx context.Context, actorID, fluctlightID string) error {
	if _, err := a.DB.GetFluctlight(ctx, fluctlightID, actorID); err != nil {
		return err
	}
	_, err := a.DB.Pool().Exec(ctx, `INSERT INTO public.moment_unread_markers(owner_fluctlight_id,actor_id,last_seen_at) VALUES($1,$2,now()) ON CONFLICT(owner_fluctlight_id,actor_id) DO UPDATE SET last_seen_at=now()`, fluctlightID, actorID)
	return err
}
func (a *App) CommentMoment(ctx context.Context, actorID, momentID, text string) (map[string]any, error) {
	if len([]rune(strings.TrimSpace(text))) == 0 || len([]rune(text)) > 32000 {
		return nil, errors.New("moment_comment_invalid")
	}
	if err := a.authorizeMoment(ctx, actorID, momentID); err != nil {
		return nil, err
	}
	id := randomID("comment_")
	_, err := a.DB.Pool().Exec(ctx, `INSERT INTO public.moment_comments(id,moment_id,author_actor_id,text) VALUES($1,$2,$3,$4)`, id, momentID, actorID, strings.TrimSpace(text))
	if err != nil {
		return nil, err
	}
	return map[string]any{"id": id, "moment_id": momentID, "author_actor_id": actorID, "text": strings.TrimSpace(text)}, nil
}
func (a *App) ReactMoment(ctx context.Context, actorID, momentID, kind string) (map[string]any, error) {
	if kind != "like" && kind != "care" && kind != "celebrate" {
		return nil, errors.New("moment_reaction_invalid")
	}
	if err := a.authorizeMoment(ctx, actorID, momentID); err != nil {
		return nil, err
	}
	kind = strings.TrimSpace(kind)
	_, err := a.DB.Pool().Exec(ctx, `INSERT INTO public.moment_reactions(moment_id,actor_id,kind) VALUES($1,$2,$3) ON CONFLICT(moment_id,actor_id) DO UPDATE SET kind=excluded.kind,created_at=now()`, momentID, actorID, kind)
	if err != nil {
		return nil, err
	}
	return map[string]any{"moment_id": momentID, "kind": kind}, nil
}
func (a *App) SetMomentStatus(ctx context.Context, actorID, momentID, status string) error {
	if status != "visible" && status != "hidden" {
		return errors.New("moment_status_invalid")
	}
	cmd, err := a.DB.Pool().Exec(ctx, `UPDATE public.moments m SET status=$2 FROM public.fluctlights f WHERE m.id=$1 AND f.id=m.owner_fluctlight_id AND f.created_by_actor_id=$3`, momentID, status, actorID)
	if err != nil {
		return err
	}
	if cmd.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

func (a *App) authorizeMoment(ctx context.Context, actorID, momentID string) error {
	var owner string
	if err := a.DB.Pool().QueryRow(ctx, `SELECT f.created_by_actor_id FROM public.moments m JOIN public.fluctlights f ON f.id=m.owner_fluctlight_id WHERE m.id=$1`, momentID).Scan(&owner); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return ErrNotFound
		}
		return err
	}
	if owner != actorID {
		return ErrUnauthorized
	}
	return nil
}

func (a *App) hydrateMoment(ctx context.Context, actorID string, moment map[string]any) error {
	momentID := stringValue(moment["id"])
	commentsRows, err := a.DB.Pool().Query(ctx, `SELECT id,author_actor_id,text,created_at FROM public.moment_comments WHERE moment_id=$1 ORDER BY created_at,id`, momentID)
	if err != nil {
		return err
	}
	comments := make([]map[string]any, 0)
	for commentsRows.Next() {
		var id, author, text string
		var created time.Time
		if err := commentsRows.Scan(&id, &author, &text, &created); err != nil {
			commentsRows.Close()
			return err
		}
		comments = append(comments, map[string]any{"id": id, "moment_id": momentID, "author_actor_id": author, "text": text, "created_at": created.Format(time.RFC3339Nano)})
	}
	commentsRows.Close()
	if err := commentsRows.Err(); err != nil {
		return err
	}
	var reactionCount int
	var viewerReaction *string
	if err := a.DB.Pool().QueryRow(ctx, `SELECT COUNT(*) FROM public.moment_reactions WHERE moment_id=$1`, momentID).Scan(&reactionCount); err != nil {
		return err
	}
	if err := a.DB.Pool().QueryRow(ctx, `SELECT kind FROM public.moment_reactions WHERE moment_id=$1 AND actor_id=$2`, momentID, actorID).Scan(&viewerReaction); err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return err
	}
	moment["comments"] = comments
	moment["reaction_count"] = reactionCount
	moment["viewer_reaction"] = viewerReaction
	media := make([]map[string]any, 0)
	for _, raw := range arrayValue(moment["media_asset_ids"]) {
		assetID := stringValue(raw)
		if assetID == "" {
			continue
		}
		var kind, mime, version, status string
		var size int
		if err := a.DB.Pool().QueryRow(ctx, `SELECT kind,mime_type,version,status,byte_size FROM public.media_assets WHERE id=$1 AND owner_fluctlight_id=(SELECT owner_fluctlight_id FROM public.moments WHERE id=$2) AND status='ready'`, assetID, momentID).Scan(&kind, &mime, &version, &status, &size); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				continue
			}
			return err
		}
		media = append(media, map[string]any{"id": assetID, "kind": kind, "mime_type": mime, "version": version, "status": status, "byte_size": size})
	}
	moment["media"] = media
	return nil
}

func (a *App) Diagnostics(ctx context.Context, actorID string, limit int) ([]map[string]any, error) {
	return a.DiagnosticsFiltered(ctx, actorID, limit, "", "")
}

func (a *App) DiagnosticsFiltered(ctx context.Context, actorID string, limit int, correlationID, fluctlightID string) ([]map[string]any, error) {
	return a.diagnosticsFiltered(ctx, actorID, limit, correlationID, fluctlightID, "")
}

func (a *App) diagnosticsFiltered(ctx context.Context, actorID string, limit int, correlationID, fluctlightID, runID string) ([]map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		return nil, err
	}
	if limit < 1 {
		limit = 100
	}
	if limit > 500 {
		limit = 500
	}
	query := `SELECT id,event_type,severity,fluctlight_id,causation_id,correlation_id,payload,created_at FROM public.diagnostic_events WHERE 1=1`
	args := make([]any, 0, 4)
	if strings.TrimSpace(correlationID) != "" {
		args = append(args, strings.TrimSpace(correlationID))
		query += fmt.Sprintf(" AND correlation_id=$%d", len(args))
	}
	if strings.TrimSpace(fluctlightID) != "" {
		args = append(args, strings.TrimSpace(fluctlightID))
		query += fmt.Sprintf(" AND fluctlight_id=$%d", len(args))
	}
	if strings.TrimSpace(runID) != "" {
		args = append(args, strings.TrimSpace(runID))
		query += fmt.Sprintf(" AND (payload->>'run_id'=$%d OR correlation_id=$%d)", len(args), len(args))
	}
	args = append(args, limit)
	query += fmt.Sprintf(" ORDER BY created_at DESC,id DESC LIMIT $%d", len(args))
	rows, err := a.DB.Pool().Query(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id, typ, severity, corr string
		var fluctlight, causation *string
		var payload []byte
		var created time.Time
		if err := rows.Scan(&id, &typ, &severity, &fluctlight, &causation, &corr, &payload, &created); err != nil {
			return nil, err
		}
		var decodedPayload any
		if json.Unmarshal(payload, &decodedPayload) != nil {
			decodedPayload = map[string]any{}
		}
		out = append(out, map[string]any{"id": id, "event_type": typ, "severity": severity, "fluctlight_id": fluctlight, "causation_id": causation, "correlation_id": corr, "payload": redactDiagnostic(decodedPayload), "created_at": created.Format(time.RFC3339Nano)})
	}
	return out, rows.Err()
}

var ErrDiagnosticsFilterInvalid = errors.New("diagnostics_filter_invalid")

type LifecycleDiagnosticsFilter struct {
	Limit         int
	FluctlightID  string
	CorrelationID string
	IntentID      string
	WorkflowID    string
	RunID         string
	Surface       string
	Status        string
}

func (value LifecycleDiagnosticsFilter) Normalized() (LifecycleDiagnosticsFilter, error) {
	if value.Limit < 1 {
		value.Limit = 100
	}
	if value.Limit > 500 {
		value.Limit = 500
	}
	identities := []*string{&value.FluctlightID, &value.CorrelationID, &value.IntentID, &value.WorkflowID, &value.RunID}
	for _, identity := range identities {
		*identity = strings.TrimSpace(*identity)
		if !validLifecycleIdentity(*identity, 128, false) {
			return LifecycleDiagnosticsFilter{}, ErrDiagnosticsFilterInvalid
		}
	}
	value.Surface = strings.TrimSpace(value.Surface)
	value.Status = strings.TrimSpace(value.Status)
	if !validLifecycleToken(value.Surface, 64, false) || !validLifecycleToken(value.Status, 64, false) {
		return LifecycleDiagnosticsFilter{}, ErrDiagnosticsFilterInvalid
	}
	return value, nil
}

func (value LifecycleDiagnosticsFilter) Map() map[string]any {
	return map[string]any{
		"limit": value.Limit, "fluctlight_id": value.FluctlightID,
		"correlation_id": value.CorrelationID, "intent_id": value.IntentID,
		"workflow_id": value.WorkflowID, "run_id": value.RunID,
		"surface": value.Surface, "status": value.Status,
	}
}

func (a *App) LifecycleDiagnostics(ctx context.Context, actorID string, filter LifecycleDiagnosticsFilter) (map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		return nil, err
	}
	normalized, err := filter.Normalized()
	if err != nil {
		return nil, err
	}
	events, err := a.lifecycleDiagnosticEvents(ctx, normalized)
	if err != nil {
		return nil, err
	}
	intents, err := a.workflowIntentSnapshots(ctx, normalized)
	if err != nil {
		return nil, err
	}
	return map[string]any{"events": events, "workflow_intents": intents, "filters": normalized.Map()}, nil
}

func buildLifecycleDiagnosticQuery(filter LifecycleDiagnosticsFilter) (string, []any) {
	query := `SELECT id,event_type,severity,fluctlight_id,causation_id,correlation_id,payload,created_at FROM public.diagnostic_events WHERE event_type LIKE 'lifecycle.%'`
	args := make([]any, 0, 8)
	add := func(clause string, value string) {
		if value == "" {
			return
		}
		args = append(args, value)
		query += fmt.Sprintf(clause, len(args))
	}
	add(" AND fluctlight_id=$%d", filter.FluctlightID)
	add(" AND correlation_id=$%d", filter.CorrelationID)
	add(" AND payload->>'intent_id'=$%d", filter.IntentID)
	if filter.WorkflowID != "" {
		args = append(args, filter.WorkflowID)
		query += fmt.Sprintf(" AND (payload->>'workflow_id'=$%d OR ('go:' || (payload->>'workflow_id'))=$%d)", len(args), len(args))
	}
	add(" AND payload->>'run_id'=$%d", filter.RunID)
	add(" AND payload->>'surface'=$%d", filter.Surface)
	add(" AND payload->>'status'=$%d", filter.Status)
	args = append(args, filter.Limit)
	query += fmt.Sprintf(" ORDER BY created_at DESC,id DESC LIMIT $%d", len(args))
	query = "SELECT id,event_type,severity,fluctlight_id,causation_id,correlation_id,payload,created_at FROM (" + query + ") AS recent_lifecycle ORDER BY created_at ASC,id ASC"
	return query, args
}

func (a *App) lifecycleDiagnosticEvents(ctx context.Context, filter LifecycleDiagnosticsFilter) ([]map[string]any, error) {
	query, args := buildLifecycleDiagnosticQuery(filter)
	rows, err := a.DB.Pool().Query(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := make([]map[string]any, 0)
	for rows.Next() {
		var id, eventType, severity, correlationID string
		var fluctlightID, causationID *string
		var rawPayload []byte
		var createdAt time.Time
		if err := rows.Scan(&id, &eventType, &severity, &fluctlightID, &causationID, &correlationID, &rawPayload, &createdAt); err != nil {
			return nil, err
		}
		var decoded any
		if json.Unmarshal(rawPayload, &decoded) != nil {
			decoded = map[string]any{}
		}
		payload := mapValue(redactDiagnostic(decoded))
		row := map[string]any{
			"id": id, "event_type": eventType, "severity": severity,
			"fluctlight_id": fluctlightID, "causation_id": causationID,
			"correlation_id": correlationID, "created_at": createdAt.UTC().Format(time.RFC3339Nano),
		}
		for _, key := range []string{
			"surface", "transition", "intent_id", "workflow_id", "run_id",
			"activity_type", "activity_id", "provider_attempt_id", "provider_request_id", "model_run_id",
			"stage", "status", "reason_code", "error_category", "error_code", "safe_cause",
			"retryable", "attempt", "max_attempts", "next_due_at", "occurred_at",
			"first_seen_at", "last_seen_at", "occurrence_count", "metadata",
		} {
			if value, ok := payload[key]; ok {
				row[key] = value
			}
		}
		result = append(result, row)
	}
	return result, rows.Err()
}

const workflowIntentCorrelationSQL = `CASE WHEN i.intent_type='wake_up.current' THEN 'wake_up:' || COALESCE(i.payload->>'fluctlight_id','unknown') || ':cycle:' || COALESCE(i.payload->>'cycle','0') ELSE COALESCE(NULLIF(i.payload->>'correlation_id',''),i.intent_id) END`

func buildWorkflowIntentSnapshotQuery(filter LifecycleDiagnosticsFilter) (string, []any) {
	query := `SELECT i.intent_id,i.workflow_id,i.task_queue,i.intent_type,COALESCE(i.status,'pending'),COALESCE(i.attempt_count,0),i.next_attempt_at,i.started_at,i.completed_at,i.last_error,i.created_at,COALESCE(i.payload->>'fluctlight_id',''),` + workflowIntentCorrelationSQL + `,COALESCE(NULLIF(i.payload->>'causation_id',''),NULLIF(i.payload->>'source_fact_id',''),NULLIF(i.payload->>'action_id',''),NULLIF(i.payload->>'inbox_id',''),'') FROM public.platform_workflow_intents AS i WHERE 1=1`
	args := make([]any, 0, 8)
	add := func(clause string, value string) {
		if value == "" {
			return
		}
		args = append(args, value)
		query += fmt.Sprintf(clause, len(args))
	}
	add(" AND i.payload->>'fluctlight_id'=$%d", filter.FluctlightID)
	if filter.CorrelationID != "" {
		args = append(args, filter.CorrelationID)
		query += fmt.Sprintf(" AND "+workflowIntentCorrelationSQL+"=$%d", len(args))
	}
	add(" AND i.intent_id=$%d", filter.IntentID)
	if filter.WorkflowID != "" {
		args = append(args, filter.WorkflowID)
		query += fmt.Sprintf(" AND (i.workflow_id=$%d OR ('go:' || i.workflow_id)=$%d)", len(args), len(args))
	}
	if filter.RunID != "" {
		args = append(args, filter.RunID)
		query += fmt.Sprintf(" AND EXISTS(SELECT 1 FROM public.diagnostic_events AS e WHERE e.event_type LIKE 'lifecycle.%%' AND e.payload->>'intent_id'=i.intent_id AND e.payload->>'run_id'=$%d)", len(args))
	}
	if filter.Surface != "" {
		intentPrefix := filter.Surface
		if intentPrefix == "conversation_summary" {
			intentPrefix = "conversation"
		}
		args = append(args, intentPrefix)
		query += fmt.Sprintf(" AND (i.intent_type=$%d OR i.intent_type LIKE ($%d || '.%%'))", len(args), len(args))
	}
	add(" AND COALESCE(i.status,'pending')=$%d", filter.Status)
	args = append(args, filter.Limit)
	query += fmt.Sprintf(" ORDER BY i.created_at DESC,i.intent_id DESC LIMIT $%d", len(args))
	return query, args
}

func (a *App) workflowIntentSnapshots(ctx context.Context, filter LifecycleDiagnosticsFilter) ([]map[string]any, error) {
	query, args := buildWorkflowIntentSnapshotQuery(filter)
	rows, err := a.DB.Pool().Query(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := make([]map[string]any, 0)
	for rows.Next() {
		var intentID, workflowID, taskQueue, intentType, status, fluctlightID, correlationID, causationID string
		var attemptCount int
		var nextAttemptAt, startedAt, completedAt *time.Time
		var lastError *string
		var createdAt time.Time
		if err := rows.Scan(&intentID, &workflowID, &taskQueue, &intentType, &status, &attemptCount, &nextAttemptAt, &startedAt, &completedAt, &lastError, &createdAt, &fluctlightID, &correlationID, &causationID); err != nil {
			return nil, err
		}
		row := map[string]any{
			"intent_id": intentID, "workflow_id": workflowID, "runtime_workflow_id": normalizedDiagnosticWorkflowID(workflowID),
			"task_queue": taskQueue, "intent_type": intentType, "status": status,
			"attempt_count": attemptCount, "fluctlight_id": nullableString(fluctlightID),
			"correlation_id": correlationID, "causation_id": nullableString(causationID),
			"created_at": createdAt.UTC().Format(time.RFC3339Nano),
		}
		if lastError != nil {
			row["last_error"] = nullableString(boundedLifecycleCause(*lastError))
		}
		if nextAttemptAt != nil {
			row["next_attempt_at"] = nextAttemptAt.UTC().Format(time.RFC3339Nano)
		}
		if startedAt != nil {
			row["started_at"] = startedAt.UTC().Format(time.RFC3339Nano)
		}
		if completedAt != nil {
			row["completed_at"] = completedAt.UTC().Format(time.RFC3339Nano)
		}
		result = append(result, row)
	}
	return result, rows.Err()
}

func normalizedDiagnosticWorkflowID(workflowID string) string {
	if strings.HasPrefix(workflowID, "go:") {
		return workflowID
	}
	return "go:" + workflowID
}

func (a *App) ClearDiagnostics(ctx context.Context, actorID string) error {
	_, err := a.ClearDiagnosticsCount(ctx, actorID)
	return err
}

func (a *App) ClearDiagnosticsCount(ctx context.Context, actorID string) (int64, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		return 0, err
	}
	var cleared int64
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		for _, table := range []string{"diagnostic_events", "diagnostic_model_runs", "diagnostic_turns", "diagnostic_workflow_links"} {
			command, err := tx.Exec(ctx, "DELETE FROM public."+table)
			if err != nil {
				return err
			}
			cleared += command.RowsAffected()
		}
		return nil
	})
	return cleared, err
}
func (a *App) ModelRuns(ctx context.Context, actorID string, limit int) ([]map[string]any, error) {
	return a.ModelRunsFiltered(ctx, actorID, limit, "")
}

func (a *App) ModelRunsFiltered(ctx context.Context, actorID string, limit int, correlationID string) ([]map[string]any, error) {
	return a.modelRunsFiltered(ctx, actorID, limit, correlationID, "")
}

// MediaPromptsFiltered returns the media-generation prompt projection used by
// the diagnostics center. Media intent creation time is the stable initiation
// order; provider/model runs and ComfyUI submission events are optional
// enrichments of the same durable media intent rather than separate rows in
// the general model-run list.
func (a *App) MediaPromptsFiltered(ctx context.Context, actorID string, limit int) ([]map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		return nil, err
	}
	if limit < 1 {
		limit = 20
	}
	if limit > 20 {
		limit = 20
	}
	rows, err := a.DB.Pool().Query(ctx, `
		SELECT mi.id,mi.owner_fluctlight_id,mi.kind,mi.mime_type,mi.prompt,mi.provider_prompt,
			mi.provider_request_id,COALESCE(mi.provider_job_id,''),mi.workflow_id,mi.status,COALESCE(mi.quality_verdict,''),COALESCE(mi.quality_retry_guidance,''),mi.created_at,
			COALESCE(event.id,''),COALESCE(event.submitted_prompt,''),COALESCE(event.request_payload,'{}'::jsonb),COALESCE(to_char(event.submitted_at,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),''),
			COALESCE(run.id,''),COALESCE(run.role,''),COALESCE(run.binding_role,''),COALESCE(run.scenario,''),COALESCE(run.priority,0),
			COALESCE(run.model_id,''),COALESCE(run.prompt,'null'::jsonb),COALESCE(run.response,'null'::jsonb),COALESCE(run.status,''),
			COALESCE(run.error_code,''),COALESCE(to_char(run.queued_at,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),to_char(mi.created_at,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')),COALESCE(to_char(run.started_at,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),''),
			COALESCE(to_char(run.completed_at,'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),''),LEFT(COALESCE(wi.last_error,''),1024),COALESCE(wi.status,''),COALESCE(wi.attempt_count,0),
			CASE WHEN COALESCE(wi.last_error,'')='' THEN '' WHEN mi.provider_job_id IS NOT NULL AND mi.provider_job_id<>'' THEN 'poll_quality' WHEN event.id IS NOT NULL AND event.id<>'' THEN 'submit' ELSE 'prepare' END
		FROM public.media_intents mi
		LEFT JOIN LATERAL (
			SELECT e.id,e.payload->>'prompt' AS submitted_prompt,e.payload->'request_payload' AS request_payload,e.created_at AS submitted_at
			FROM public.diagnostic_events e
			WHERE e.event_type='media.comfyui.prompt_submitted' AND e.correlation_id='media:'||mi.id
			ORDER BY e.created_at DESC,e.id DESC
			LIMIT 1
		) event ON true
		LEFT JOIN public.platform_workflow_intents wi ON wi.workflow_id=mi.workflow_id AND wi.intent_type='media.generation'
		LEFT JOIN LATERAL (
			SELECT r.id,r.role,r.binding_role,r.scenario,r.priority,r.model_id,r.prompt,r.response,r.status,r.error_code,r.queued_at,r.started_at,r.completed_at
			FROM public.diagnostic_model_runs r
			WHERE r.correlation_id='media:'||mi.id AND r.scenario='media_prompt'
			ORDER BY r.queued_at DESC,r.id DESC
			LIMIT 1
		) run ON true
		ORDER BY mi.created_at DESC,mi.id DESC
		LIMIT $1`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id, owner, kind, mime, prompt, providerPrompt, requestID, jobID, workflow, status, qualityVerdict, qualityGuidance, eventID, submittedPrompt, submittedAt, workflowError, workflowStatus, failureStage string
		var runID, runRole, runBinding, runScenario, runModel, runStatus, runError, runQueued, runStarted, runCompleted string
		var runPriority, workflowAttempts int
		var runPrompt, runResponse, submittedPayload []byte
		var created time.Time
		if err := rows.Scan(&id, &owner, &kind, &mime, &prompt, &providerPrompt, &requestID, &jobID, &workflow, &status, &qualityVerdict, &qualityGuidance, &created, &eventID, &submittedPrompt, &submittedPayload, &submittedAt, &runID, &runRole, &runBinding, &runScenario, &runPriority, &runModel, &runPrompt, &runResponse, &runStatus, &runError, &runQueued, &runStarted, &runCompleted, &workflowError, &workflowStatus, &workflowAttempts, &failureStage); err != nil {
			return nil, err
		}
		promptValue := any(prompt)
		if json.Valid([]byte(prompt)) {
			promptValue = json.RawMessage(prompt)
		}
		row := map[string]any{
			"id": id, "media_intent_id": id, "fluctlight_id": owner, "kind": kind, "mime_type": mime,
			"prompt": promptValue, "provider_prompt": providerPrompt, "submitted_prompt": submittedPrompt,
			"provider_request_id": requestID, "provider_job_id": jobID, "workflow_id": workflow, "status": status, "quality_verdict": qualityVerdict,
			"correlation_id": "media:" + id, "created_at": created.Format(time.RFC3339Nano),
		}
		if eventID != "" {
			row["submitted_event_id"] = eventID
			if json.Valid(submittedPayload) && string(submittedPayload) != "{}" {
				row["request_payload"] = json.RawMessage(submittedPayload)
			}
			row["submitted_at"] = submittedAt
		}
		if workflowError == "" && status == "failed" {
			if qualityVerdict == mediaQualityVerdictReject {
				workflowError = "媒体质量检查未通过"
				if qualityGuidance != "" {
					workflowError += ": " + qualityGuidance
				}
			} else {
				workflowError = "媒体生成失败，但没有记录更详细的错误信息"
			}
			if failureStage == "" {
				failureStage = "poll_quality"
			}
		}
		if workflowError != "" {
			row["error_message"] = workflowError
			row["failure_stage"] = failureStage
			row["workflow_status"] = workflowStatus
			row["attempt_count"] = workflowAttempts
		}
		if runID != "" {
			modelRun := map[string]any{
				"id": runID, "role": runRole, "binding_role": runBinding, "scenario": runScenario,
				"priority": runPriority, "model_id": runModel, "prompt": json.RawMessage(runPrompt),
				"response": json.RawMessage(runResponse), "status": runStatus, "error_code": runError,
				"queued_at": runQueued, "correlation_id": "media:" + id,
			}
			if runStarted != "" {
				modelRun["started_at"] = runStarted
			}
			if runCompleted != "" {
				modelRun["completed_at"] = runCompleted
			}
			row["model_run"] = modelRun
		}
		out = append(out, row)
	}
	return out, rows.Err()
}

// RetryMediaIntent resets one failed media target while preserving its frozen
// provider prompt. The existing workflow restart path is reused so a retry
// gets a new ComfyUI submission and fresh diagnostic event without creating a
// second media intent.
func (a *App) RetryMediaIntent(ctx context.Context, actorID, intentID string) (map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		return nil, err
	}
	var workflowID, mediaStatus, workflowStatus, ownerFluctlightID, providerRequestID string
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `SELECT workflow_id,status,owner_fluctlight_id,provider_request_id FROM public.media_intents WHERE id=$1 FOR UPDATE`, intentID).Scan(&workflowID, &mediaStatus, &ownerFluctlightID, &providerRequestID); errors.Is(err, pgx.ErrNoRows) {
			return ErrNotFound
		} else if err != nil {
			return err
		}
		// Lock the workflow row separately. PostgreSQL cannot apply FOR UPDATE
		// to the nullable side of the outer join that is needed to repair legacy
		// media rows without a workflow intent.
		if err := tx.QueryRow(ctx, `SELECT status FROM public.platform_workflow_intents WHERE workflow_id=$1 AND intent_type='media.generation' FOR UPDATE`, workflowID).Scan(&workflowStatus); errors.Is(err, pgx.ErrNoRows) {
			workflowStatus = ""
		} else if err != nil {
			return err
		}
		if mediaStatus != "failed" && workflowStatus != "failed" {
			return ErrConflict
		}
		if workflowStatus == "started" || workflowStatus == "paused" || workflowStatus == "cancel_requested" {
			return ErrConflict
		}
		if _, err := tx.Exec(ctx, `UPDATE public.media_intents SET provider_job_id=NULL,status='pending',quality_verdict='',quality_candidate_sha256=NULL,quality_checked_at=NULL,revision=revision+1 WHERE id=$1`, intentID); err != nil {
			return err
		}
		if workflowStatus == "" {
			// Older media rows may predate the durable workflow-intent record.
			// Recreate that record from the media intent before restarting so the
			// retry does not get stuck at an irreversible not-found error.
			if _, err := tx.Exec(ctx, `INSERT INTO public.platform_workflow_intents (intent_id,workflow_id,task_queue,intent_type,payload) VALUES ($1,$2,'media','media.generation',jsonb_build_object('intent_id',$3,'provider_request_id',$4,'fluctlight_id',$5)) ON CONFLICT (workflow_id) DO NOTHING`, "media_workflow_intent:"+intentID, workflowID, intentID, providerRequestID, ownerFluctlightID); err != nil {
				return err
			}
		}
		command, err := tx.Exec(ctx, `UPDATE public.platform_workflow_intents SET status='pending',attempt_count=0,last_error=NULL,next_attempt_at=now(),started_at=NULL,completed_at=NULL WHERE workflow_id=$1 AND intent_type='media.generation'`, workflowID)
		if err != nil {
			return err
		}
		if command.RowsAffected() != 1 {
			return ErrNotFound
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	if a.Workflows == nil {
		return map[string]any{"media_intent_id": intentID, "workflow_id": workflowID, "status": "retry_queued"}, nil
	}
	if _, err := a.WorkflowCommand(ctx, actorID, workflowID, "restart", nil); err != nil {
		bounded := visualIdentityBoundedText(strings.Join(strings.Fields(err.Error()), " "), 1024)
		if mediaRetryRestartIsPermanent(err) {
			if persistErr := a.persistPermanentMediaRetryFailure(ctx, intentID, workflowID, bounded); persistErr != nil {
				return nil, fmt.Errorf("%w; retry state persistence failed: %v", err, persistErr)
			}
			return nil, err
		}
		if _, persistErr := a.DB.Pool().Exec(ctx, `UPDATE public.platform_workflow_intents SET status='retry',last_error=$2,next_attempt_at=now()+interval '5 seconds' WHERE workflow_id=$1 AND intent_type='media.generation'`, workflowID, bounded); persistErr != nil {
			return nil, fmt.Errorf("%w; retry state persistence failed: %v", err, persistErr)
		}
		// The durable row is still queued for the Worker. A transient Temporal
		// restart failure should not make the browser retry button unusable; the
		// next dispatcher pass will retry using the same stable workflow ID.
		return map[string]any{"media_intent_id": intentID, "workflow_id": workflowID, "status": "retry_queued"}, nil
	}
	return map[string]any{"media_intent_id": intentID, "workflow_id": workflowID, "status": "retry_queued"}, nil
}

func (a *App) persistPermanentMediaRetryFailure(ctx context.Context, intentID, workflowID, message string) error {
	return withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE public.media_intents SET status='failed',revision=revision+1 WHERE id=$1 AND status='pending'`, intentID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE public.platform_workflow_intents SET status='failed',last_error=$2,completed_at=now() WHERE workflow_id=$1 AND intent_type='media.generation'`, workflowID, message); err != nil {
			return err
		}
		if _, err := a.settleActionOutcomeByExternalRefTx(ctx, tx, intentID, ActionOutcomeFailed, map[string]any{"media_intent_id": intentID, "status": "failed", "reason_code": "media_workflow_terminal_failure"}, "media_workflow_terminal_failure"); err != nil {
			return err
		}
		return nil
	})
}

func (a *App) RecordMediaActivityFailure(ctx context.Context, intentID, message string) error {
	if a == nil || strings.TrimSpace(intentID) == "" {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 2*time.Second)
	defer cancel()
	return withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `UPDATE public.media_intents SET status='failed',revision=revision+1 WHERE id=$1 AND status IN ('pending','running')`, intentID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE public.platform_workflow_intents SET last_error=$2 WHERE workflow_id=(SELECT workflow_id FROM public.media_intents WHERE id=$1) AND intent_type='media.generation' AND status IN ('pending','started','retry')`, intentID, message); err != nil {
			return err
		}
		return nil
	})
}

func mediaRetryRestartIsPermanent(err error) bool {
	if err == nil {
		return false
	}
	message := strings.ToLower(err.Error())
	for _, marker := range []string{
		"workflow payload is invalid",
		"unsupported workflow intent type",
		"workflow restart identity is incomplete",
		"media_intent_not_found",
	} {
		if strings.Contains(message, marker) {
			return true
		}
	}
	return false
}

func (a *App) DiagnosticsExport(ctx context.Context, actorID string) (map[string]any, error) {
	return a.DiagnosticsExportFiltered(ctx, actorID, LifecycleDiagnosticsFilter{Limit: 200})
}

func (a *App) DiagnosticsExportFiltered(ctx context.Context, actorID string, filter LifecycleDiagnosticsFilter) (map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		return nil, err
	}
	normalized, err := filter.Normalized()
	if err != nil {
		return nil, err
	}
	var events []map[string]any
	if normalized.RunID == "" {
		events, err = a.DiagnosticsFiltered(ctx, actorID, normalized.Limit, normalized.CorrelationID, normalized.FluctlightID)
	} else {
		events, err = a.diagnosticsFiltered(ctx, actorID, normalized.Limit, normalized.CorrelationID, normalized.FluctlightID, normalized.RunID)
	}
	if err != nil {
		return nil, err
	}
	var runs []map[string]any
	if normalized.RunID == "" {
		runs, err = a.ModelRunsFiltered(ctx, actorID, normalized.Limit, normalized.CorrelationID)
	} else {
		runs, err = a.modelRunsFiltered(ctx, actorID, normalized.Limit, normalized.CorrelationID, normalized.RunID)
	}
	if err != nil {
		return nil, err
	}
	mediaPrompts, err := a.MediaPromptsFiltered(ctx, actorID, 20)
	if err != nil {
		return nil, err
	}
	lifecycle, err := a.LifecycleDiagnostics(ctx, actorID, normalized)
	if err != nil {
		return nil, err
	}
	return map[string]any{
		"events": events, "model_runs": runs, "media_prompts": mediaPrompts,
		"lifecycle": lifecycle["events"], "workflow_intents": lifecycle["workflow_intents"],
		"filters": normalized.Map(),
	}, nil
}

// RecoverStaleModelRuns closes lifecycle records left behind by a crashed API
// or Worker process. The in-memory queue cannot resume a lost callback, so a
// stale request is terminally marked with a bounded infrastructure reason;
// its owning domain workflow remains responsible for retrying the operation.
func (a *App) RecoverStaleModelRuns(ctx context.Context, olderThan time.Duration) (int64, error) {
	if olderThan <= 0 {
		olderThan = 15 * time.Minute
	}
	command, err := a.DB.Pool().Exec(ctx, `UPDATE public.diagnostic_model_runs SET status='failed',error_code='provider_process_restarted',completed_at=COALESCE(completed_at,now()) WHERE status IN ('queued','running') AND COALESCE(started_at,queued_at,created_at) < now()-$1::interval`, fmt.Sprintf("%d seconds", int64(olderThan/time.Second)))
	if err != nil {
		return 0, err
	}
	return command.RowsAffected(), nil
}

// PruneDiagnostics enforces the local retention contract without touching any
// domain audit/revision/evidence tables. It is safe to call from a periodic
// Worker tick; each DELETE is bounded by the configured row cap.
func (a *App) PruneDiagnostics(ctx context.Context, olderThan time.Duration, maxRows int) (int64, error) {
	if olderThan <= 0 {
		olderThan = 30 * 24 * time.Hour
	}
	if maxRows < 1 {
		maxRows = 10000
	}
	var removed int64
	err := withTransaction(ctx, a.DB.Pool(), func(tx pgx.Tx) error {
		for _, table := range []string{"diagnostic_events", "diagnostic_model_runs", "diagnostic_turns", "diagnostic_workflow_links"} {
			command, err := tx.Exec(ctx, `DELETE FROM public.`+table+` WHERE created_at < now()-$1::interval OR id IN (SELECT id FROM public.`+table+` ORDER BY created_at DESC OFFSET $2)`, fmt.Sprintf("%d seconds", int64(olderThan/time.Second)), maxRows)
			if err != nil {
				return err
			}
			removed += command.RowsAffected()
		}
		return nil
	})
	return removed, err
}

var ErrWorkflowRuntime = errors.New("workflow_runtime_unavailable")

func (a *App) WorkflowList(ctx context.Context, actorID, query string) ([]map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		slog.Warn("workflow list owner authorization failed", "actor_id", actorID)
		_ = a.auditWorkflow(ctx, actorID, "list", "", false, map[string]any{"query": query})
		return nil, err
	}
	if a.Workflows == nil {
		return nil, ErrWorkflowRuntime
	}
	executions, err := a.Workflows.List(ctx, query, 200)
	if err != nil {
		_ = a.auditWorkflow(ctx, actorID, "list", "", true, map[string]any{"query": query, "error": "runtime_unavailable"})
		return nil, fmt.Errorf("%w: %v", ErrWorkflowRuntime, err)
	}
	if err := a.auditWorkflow(ctx, actorID, "list", "", true, map[string]any{"query": query, "count": len(executions)}); err != nil {
		return nil, err
	}
	out := make([]map[string]any, 0, len(executions))
	for _, execution := range executions {
		out = append(out, workflowExecutionMap(execution))
	}
	return out, nil
}

func (a *App) WorkflowStatus(ctx context.Context, actorID, wf string) (map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		_ = a.auditWorkflow(ctx, actorID, "status", wf, false, nil)
		return nil, err
	}
	intent, queue, intentType, payload, err := a.workflowIntent(ctx, wf)
	if err != nil {
		slog.Warn("workflow status intent lookup failed", "workflow_id", wf, "error", err)
		return nil, err
	}
	if a.Workflows == nil {
		return nil, ErrWorkflowRuntime
	}
	execution, err := a.Workflows.Status(ctx, wf, "")
	if err != nil {
		slog.Warn("workflow status runtime lookup failed", "workflow_id", wf, "error", err)
		_ = a.auditWorkflow(ctx, actorID, "status", wf, true, map[string]any{"error": "runtime_unavailable"})
		return nil, fmt.Errorf("%w: %v", ErrWorkflowRuntime, err)
	}
	if err := a.auditWorkflow(ctx, actorID, "status", wf, true, map[string]any{"status": execution.Status}); err != nil {
		return nil, err
	}
	value := workflowExecutionMap(execution)
	value["intent_id"] = intent
	value["task_queue"] = queue
	value["intent_type"] = intentType
	value["payload"] = json.RawMessage(payload)
	return value, nil
}

func (a *App) WorkflowHistory(ctx context.Context, actorID, wf string) (map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		_ = a.auditWorkflow(ctx, actorID, "history", wf, false, nil)
		return nil, err
	}
	if _, _, _, _, err := a.workflowIntent(ctx, wf); err != nil {
		return nil, err
	}
	if a.Workflows == nil {
		return nil, ErrWorkflowRuntime
	}
	history, err := a.Workflows.History(ctx, wf, "", 50)
	if err != nil {
		_ = a.auditWorkflow(ctx, actorID, "history", wf, true, map[string]any{"error": "runtime_unavailable"})
		return nil, fmt.Errorf("%w: %v", ErrWorkflowRuntime, err)
	}
	if err := a.auditWorkflow(ctx, actorID, "history", wf, true, map[string]any{"event_count": history.EventCount}); err != nil {
		return nil, err
	}
	return map[string]any{"workflow_id": history.WorkflowID, "run_id": history.RunID, "event_count": history.EventCount, "event_types": history.EventTypes}, nil
}

func (a *App) WorkflowCommand(ctx context.Context, actorID, wf, action string, payload map[string]any) (map[string]any, error) {
	if err := a.requireOwner(ctx, actorID); err != nil {
		_ = a.auditWorkflow(ctx, actorID, action, wf, false, map[string]any{"error": "forbidden"})
		return nil, err
	}
	intentID, queue, intentType, intentPayload, err := a.workflowIntent(ctx, wf)
	if err != nil {
		return nil, err
	}
	if a.Workflows == nil {
		return nil, ErrWorkflowRuntime
	}
	requestID := stringValue(payload["request_id"])
	if requestID == "" {
		requestID = stableDigest(fmt.Sprintf("%s:%s:%s:%s", actorID, action, wf, intentID))
	}
	var result map[string]any
	switch action {
	case "pause", "resume":
		if err := a.Workflows.Signal(ctx, wf, "", action, requestID); err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		intentStatus := "paused"
		if action == "resume" {
			intentStatus = "started"
		}
		if err := a.updateWorkflowIntentStatus(ctx, wf, intentStatus); err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		result = map[string]any{"workflow_id": wf, "operation": action, "status": "accepted"}
	case "cancel":
		if err := a.Workflows.Cancel(ctx, wf, "", requestID); err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		if err := a.updateWorkflowIntentStatus(ctx, wf, "cancel_requested"); err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		result = map[string]any{"workflow_id": wf, "operation": action, "status": "accepted"}
	case "reset":
		historyPoint, ok := positiveInt64(payload["history_point"])
		if !ok {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, errors.New("history_point must be greater than zero"))
		}
		execution, err := a.Workflows.Reset(ctx, wf, "", historyPoint, "owner requested workflow reset", requestID)
		if err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		if err := a.updateWorkflowIntentStatus(ctx, wf, "started"); err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		result = workflowExecutionMap(execution)
		result["operation"] = action
	case "restart":
		execution, err := a.Workflows.Restart(ctx, WorkflowStart{WorkflowID: wf, TaskQueue: queue, IntentType: intentType, Payload: intentPayload})
		if err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		if err := a.updateWorkflowIntentStatus(ctx, wf, "started"); err != nil {
			return nil, a.workflowCommandFailure(ctx, actorID, action, wf, err)
		}
		result = workflowExecutionMap(execution)
		result["operation"] = action
	default:
		return nil, a.workflowCommandFailure(ctx, actorID, action, wf, errors.New("unsupported workflow command"))
	}
	if err := a.auditWorkflow(ctx, actorID, action, wf, true, map[string]any{"status": result["status"], "request_id": requestID}); err != nil {
		return nil, err
	}
	return result, nil
}

func (a *App) workflowCommandFailure(ctx context.Context, actorID, action, workflowID string, err error) error {
	_ = a.auditWorkflow(ctx, actorID, action, workflowID, true, map[string]any{"error": "command_failed"})
	return fmt.Errorf("workflow %s failed: %w", action, err)
}

func (a *App) requireOwner(ctx context.Context, actorID string) error {
	var owner string
	if err := a.DB.Pool().QueryRow(ctx, `SELECT human_actor_id FROM public.owner_accounts LIMIT 1`).Scan(&owner); err != nil {
		return ErrUnauthorized
	}
	if owner == "" || owner != actorID {
		return ErrUnauthorized
	}
	return nil
}

func (a *App) workflowIntent(ctx context.Context, workflowID string) (string, string, string, []byte, error) {
	var intentID, queue, intentType string
	var payload []byte
	if err := a.DB.Pool().QueryRow(ctx, `SELECT intent_id,task_queue,intent_type,payload FROM public.platform_workflow_intents WHERE workflow_id=$1 OR ('go:' || workflow_id)=$1 ORDER BY CASE WHEN workflow_id=$1 THEN 0 ELSE 1 END LIMIT 1`, workflowID).Scan(&intentID, &queue, &intentType, &payload); errors.Is(err, pgx.ErrNoRows) {
		return "", "", "", nil, ErrNotFound
	} else if err != nil {
		return "", "", "", nil, err
	}
	return intentID, queue, intentType, payload, nil
}

func (a *App) updateWorkflowIntentStatus(ctx context.Context, workflowID, status string) error {
	command, err := a.DB.Pool().Exec(ctx, `UPDATE public.platform_workflow_intents SET status=$2,last_error=NULL WHERE workflow_id=$1 OR ('go:' || workflow_id)=$1`, workflowID, status)
	if err != nil {
		return err
	}
	if command.RowsAffected() != 1 {
		return errors.New("workflow_intent_status_not_written")
	}
	return nil
}

func (a *App) auditWorkflow(ctx context.Context, actorID, action, workflowID string, authorized bool, details map[string]any) error {
	if details == nil {
		details = map[string]any{}
	}
	details["authorized"] = authorized
	encoded, err := json.Marshal(details)
	if err != nil {
		return err
	}
	auditID := "workflow_audit_" + stableDigest(strings.Join([]string{actorID, action, workflowID, string(encoded)}, ":"))
	_, err = a.DB.Pool().Exec(ctx, `INSERT INTO public.platform_workflow_management_audit(id,action,workflow_id,actor_id,authorized,details) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(id) DO UPDATE SET details=EXCLUDED.details,created_at=now()`, auditID, action, workflowID, actorID, strconv.FormatBool(authorized), encoded)
	return err
}

func workflowExecutionMap(execution WorkflowExecution) map[string]any {
	value := map[string]any{"workflow_id": execution.WorkflowID, "run_id": execution.RunID, "workflow_type": execution.WorkflowType, "task_queue": execution.TaskQueue, "status": execution.Status, "history_length": execution.HistoryLength}
	if execution.StartTime != nil {
		value["start_time"] = execution.StartTime.Format(time.RFC3339Nano)
	}
	if execution.CloseTime != nil {
		value["close_time"] = execution.CloseTime.Format(time.RFC3339Nano)
	}
	return value
}

func positiveInt64(value any) (int64, bool) {
	switch v := value.(type) {
	case int:
		return int64(v), v > 0
	case int64:
		return v, v > 0
	case float64:
		return int64(v), v > 0 && v == float64(int64(v))
	case json.Number:
		i, err := v.Int64()
		return i, err == nil && i > 0
	case string:
		i, err := strconv.ParseInt(strings.TrimSpace(v), 10, 64)
		return i, err == nil && i > 0
	default:
		return 0, false
	}
}
