package core

import (
	"strings"

	"github.com/fluctlight/local-ai-companion/apps/core-go/internal/conversation"
)

type canonicalVisibleReply = conversation.CanonicalVisibleReply

const (
	canonicalVisibleSourceResponsePlan    = conversation.CanonicalVisibleSourceResponsePlan
	canonicalVisibleSourceDecision        = conversation.CanonicalVisibleSourceDecision
	canonicalVisibleSourceReplyCapability = conversation.CanonicalVisibleSourceReplyCapability

	canonicalVisibleTextConflictCode = conversation.CanonicalVisibleTextConflictCode
)

type visibleTextDiagnostic = conversation.VisibleTextDiagnostic

// resolveCanonicalVisibleReply picks the single authoritative visible text and
// reports whether the candidate sources disagreed. Under the F-01 path b
// contract the root visible_text fields (response_plan, then decision) are the
// preferred proposal protocol; conversation.reply remains a fallback a
// reply-only candidate may use (Core derives the root field from it), but a
// reply argument that disagrees with the root visible_text is a conflict the
// normalizer must fail closed instead of silently choosing the root
// precedence, so the model can never produce two texts.
func resolveCanonicalVisibleReply(responsePlan, decision map[string]any, invocations []CapabilityInvocation, registry *CapabilityRegistry) (canonicalVisibleReply, []visibleTextDiagnostic) {
	planText := normalizeVisibleReply(stringValue(mapValue(responsePlan)["visible_text"]))
	decisionText := normalizeVisibleReply(stringValue(mapValue(decision)["visible_text"]))
	replyText := replyTextFromCapabilityInvocations(invocations, registry)

	result := canonicalVisibleReply{}
	switch {
	case planText != "":
		result.Text, result.Source = planText, canonicalVisibleSourceResponsePlan
	case decisionText != "":
		result.Text, result.Source = decisionText, canonicalVisibleSourceDecision
	case replyText != "":
		result.Text, result.Source = replyText, canonicalVisibleSourceReplyCapability
	}

	var diagnostics []visibleTextDiagnostic
	if len(distinctVisibleTexts(planText, decisionText, replyText)) > 1 {
		result.Conflict = true
		diagnostics = append(diagnostics, visibleTextDiagnostic{
			Code:   canonicalVisibleTextConflictCode,
			Winner: result.Source,
			Detail: "the candidate sources disagreed; the root visible_text is the sole authority and a conflicting reply argument must fail closed",
		})
	}
	if result.Text != "" {
		result.Digest = stableDigest(result.Text)
	}
	for index := range diagnostics {
		diagnostics[index].Digest = result.Digest
	}
	return result, diagnostics
}

// distinctVisibleTexts returns the set of unique, non-empty candidate texts,
// preserving first-seen order so the diagnostic stays deterministic.
func distinctVisibleTexts(values ...string) []string {
	seen := make(map[string]struct{}, len(values))
	result := make([]string, 0, len(values))
	for _, value := range values {
		if value == "" {
			continue
		}
		if _, exists := seen[value]; exists {
			continue
		}
		seen[value] = struct{}{}
		result = append(result, value)
	}
	return result
}

// normalizeVisibleReply removes transport/protocol wrappers that a text-only
// realization model may return despite the plain-text contract. Structured
// action objects are control payloads; only their user-facing content belongs
// in a conversation message.
func normalizeVisibleReply(value string) string {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return ""
	}
	object, ok := visibleReplyObject(trimmed)
	if !ok {
		return trimmed
	}
	if action := mapValue(object["action"]); len(action) > 0 {
		for _, key := range []string{"content", "text", "visible_text", "message"} {
			if text := strings.TrimSpace(stringValue(action[key])); text != "" {
				return text
			}
		}
		return ""
	}
	for _, key := range []string{"content", "text", "visible_text", "message"} {
		if text := strings.TrimSpace(stringValue(object[key])); text != "" {
			return text
		}
	}
	return trimmed
}

func visibleReplyIsStructured(value string) bool {
	trimmed := strings.TrimSpace(value)
	if !visibleReplyLooksStructured(trimmed) {
		return false
	}
	object, ok := visibleReplyObject(trimmed)
	if !ok {
		return false
	}
	return len(mapValue(object["action"])) > 0
}

func visibleReplyObject(value string) (map[string]any, bool) {
	structured, ok := parseStructuredCandidate(value, 0)
	return structured, ok && structured != nil
}

func visibleReplyLooksStructured(value string) bool {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return false
	}
	if trimmed[0] == '{' || trimmed[0] == '[' {
		return true
	}
	return false
}

// newVisibleReplyStream buffers only JSON-looking output so a protocol object
// is never emitted as a visible token. Ordinary Chinese text continues to
// stream immediately; a structured action is emitted once, after its content
// has been extracted.
func newVisibleReplyStream(onChunk func(string) error) (func(string) error, func() bool) {
	var buffer strings.Builder
	emitted := false
	decided := false
	push := func(chunk string) error {
		if onChunk == nil {
			return nil
		}
		if decided {
			emitted = true
			return onChunk(chunk)
		}
		buffer.WriteString(chunk)
		candidate := strings.TrimSpace(buffer.String())
		if candidate == "" {
			return nil
		}
		if visibleReplyIsStructured(candidate) {
			decided = true
			emitted = true
			return onChunk(normalizeVisibleReply(candidate))
		}
		if visibleReplyLooksStructured(candidate) {
			// Hold a bounded JSON-looking prefix until the complete object arrives;
			// malformed/ordinary prose is flushed rather than held indefinitely.
			if len([]rune(candidate)) <= 4096 {
				return nil
			}
		}
		decided = true
		text := buffer.String()
		buffer.Reset()
		emitted = true
		return onChunk(text)
	}
	return push, func() bool { return emitted }
}
