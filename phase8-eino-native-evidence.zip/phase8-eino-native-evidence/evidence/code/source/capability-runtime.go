package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

func (a *App) capabilityRegistry() *CapabilityRegistry {
	if a != nil && a.Capabilities != nil {
		return a.Capabilities
	}
	registry, _ := NewCapabilityRegistry(builtinCapabilities(a)...)
	return registry
}

func (a *App) capabilityRuntime() *CapabilityRuntime {
	if a != nil && a.Runtime != nil {
		return a.Runtime
	}
	registry := a.capabilityRegistry()
	if a == nil || a.ContextResolver == nil {
		return nil
	}
	resolver := a.ContextResolver
	runtime, err := NewCapabilityRuntime(registry, resolver)
	if err != nil {
		return nil
	}
	if a != nil {
		a.Runtime = runtime
	}
	return runtime
}

func capabilityCatalog(registry *CapabilityRegistry, surface CapabilitySurface) []CapabilityDefinition {
	if registry == nil {
		return nil
	}
	return registry.Catalog(surface)
}

// capabilityInvocationBatchError carries the per-call failures collected while
// a batch is being prepared or planned.  The batch itself is deliberately not
// an all-or-nothing boundary: callers must persist these failures next to the
// corresponding call and continue with every sibling that reached its own
// boundary successfully.  Unwrap keeps the historical errors.Is/errors.As
// behavior for callers that still need the first concrete cause.
type capabilityInvocationBatchError struct {
	Failures []CapabilityResult
	First    error
}

func (err *capabilityInvocationBatchError) Error() string {
	if err == nil {
		return ""
	}
	if err.First != nil {
		return err.First.Error()
	}
	return "capability invocation batch failed"
}

func (err *capabilityInvocationBatchError) Unwrap() error {
	if err == nil {
		return nil
	}
	return err.First
}

func (err *capabilityInvocationBatchError) add(invocation CapabilityInvocation, cause error, fallbackCode string) {
	if err == nil || cause == nil {
		return
	}
	if err.First == nil {
		err.First = cause
	}
	code, retryable := capabilityErrorInfo(cause, fallbackCode, true)
	if errors.Is(cause, ErrCapabilityNotFound) || errors.Is(cause, ErrInvalidArguments) || errors.Is(cause, ErrUnauthorized) {
		retryable = false
	}
	err.Failures = replaceCapabilityResult(err.Failures, failedCapabilityResultDetail(invocation, code, retryable, cause.Error()))
}

func capabilityBatchFailures(err error) []CapabilityResult {
	var batch *capabilityInvocationBatchError
	if errors.As(err, &batch) && batch != nil {
		return append([]CapabilityResult(nil), batch.Failures...)
	}
	return nil
}

func mergeCapabilityResults(existing, additions []CapabilityResult) []CapabilityResult {
	merged := append([]CapabilityResult(nil), existing...)
	for _, addition := range additions {
		merged = replaceCapabilityResult(merged, addition)
	}
	return merged
}

func mergeCapabilityResultsFromValue(value any, additions []CapabilityResult) []CapabilityResult {
	existing, err := capabilityResultsFromValue(value)
	if err != nil {
		existing = nil
	}
	return mergeCapabilityResults(existing, additions)
}

func capabilityResultValues(results []CapabilityResult) []any {
	values := make([]any, 0, len(results))
	for _, result := range results {
		values = append(values, result)
	}
	return values
}

// ExecuteCapabilities is the standalone planning/query entry point. It never
// self-commits a transactional Capability; callers that own an action use the
// frozen plan plus settleDeferredCapabilitiesTx in their Unit of Work.
func (a *App) ExecuteCapabilities(ctx context.Context, fluctlightID, conversationID, sourceFactID string, invocations []CapabilityInvocation) ([]CapabilityResult, error) {
	return a.executeCapabilities(ctx, fluctlightID, conversationID, sourceFactID, invocations, nil, true, true, true)
}

func (a *App) planCapabilitiesForTransaction(ctx context.Context, fluctlightID, conversationID, sourceFactID string, invocations []CapabilityInvocation, existing []CapabilityResult) ([]CapabilityResult, error) {
	// Transaction plans are built only after the caller has frozen and
	// persisted Capability Prepare output. Re-running the preparer here would
	// make planner I/O depend on the settlement attempt instead of the frozen
	// replay boundary.
	return a.executeCapabilities(ctx, fluctlightID, conversationID, sourceFactID, invocations, existing, true, false, false)
}

func (a *App) executeCapabilities(ctx context.Context, fluctlightID, conversationID, sourceFactID string, invocations []CapabilityInvocation, existing []CapabilityResult, deferTransactional, persistStandaloneOutcomes, prepareInvocations bool) ([]CapabilityResult, error) {
	if len(invocations) == 0 {
		return []CapabilityResult{}, nil
	}
	runtime := a.capabilityRuntime()
	if runtime == nil {
		results := make([]CapabilityResult, 0, len(invocations))
		for _, invocation := range invocations {
			results = append(results, failedCapabilityResultDetail(invocation, "capability_not_found", false, "capability runtime is unavailable"))
		}
		return results, ErrCapabilityNotFound
	}
	registry := runtime.Registry
	results := append([]CapabilityResult(nil), existing...)
	var firstErr error
	batchErr := &capabilityInvocationBatchError{}
	for index := range invocations {
		invocation := normalizeCapabilityInvocationMetadata(invocations[index], fluctlightID, conversationID, sourceFactID, sourceFactID, index)
		invocations[index] = invocation
		if existingResult, found := capabilityResultForCall(results, invocation.CallID); found {
			if existingResult.CapabilityName != invocation.CapabilityName {
				return results, fmt.Errorf("capability result identity mismatch for call %q", invocation.CallID)
			}
			if existingResult.Status == "completed" || existingResult.Status == "failed" || existingResult.Status == "rejected" {
				continue
			}
		}
		definition, ok := registry.Definition(invocation.CapabilityName)
		if !ok {
			result := failedCapabilityResultDetail(invocation, "capability_not_found", false, invocation.CapabilityName)
			results = replaceCapabilityResult(results, result)
			batchErr.Failures = replaceCapabilityResult(batchErr.Failures, result)
			if firstErr == nil {
				firstErr = fmt.Errorf("%w: %s", ErrCapabilityNotFound, invocation.CapabilityName)
				batchErr.First = firstErr
			}
			continue
		}
		capability, ok := registry.LookupCapability(invocation.CapabilityName)
		if !ok {
			result := failedCapabilityResultDetail(invocation, "capability_not_found", false, "implementation is not registered")
			results = replaceCapabilityResult(results, result)
			batchErr.Failures = replaceCapabilityResult(batchErr.Failures, result)
			if firstErr == nil {
				firstErr = fmt.Errorf("%w: %s", ErrCapabilityNotFound, invocation.CapabilityName)
				batchErr.First = firstErr
			}
			continue
		}
		executionClass, classErr := classifyCapabilityExecution(capability, definition)
		if classErr != nil {
			result := failedCapabilityResultDetail(invocation, "capability_execution_class_invalid", false, classErr.Error())
			results = replaceCapabilityResult(results, result)
			batchErr.Failures = replaceCapabilityResult(batchErr.Failures, result)
			if firstErr == nil && definition.FailurePolicy == FailurePolicyRequiredForVisibleClaim {
				firstErr = classErr
				batchErr.First = firstErr
			}
			continue
		}
		if prepareInvocations {
			if len(invocation.PreparedPayload) > 0 {
				if _, prepareErr := decodeCapabilityPreparedPayload(invocation.PreparedPayload); prepareErr != nil {
					result := failedCapabilityResultDetail(invocation, "capability_prepared_payload_invalid", false, prepareErr.Error())
					results = replaceCapabilityResult(results, result)
					batchErr.Failures = replaceCapabilityResult(batchErr.Failures, result)
					if firstErr == nil && definition.FailurePolicy == FailurePolicyRequiredForVisibleClaim {
						firstErr = prepareErr
						batchErr.First = firstErr
					}
					continue
				}
			} else {
				prepared, _, prepareErr := runtime.Prepare(ctx, invocation)
				if prepareErr != nil {
					code, retryable := capabilityErrorInfo(prepareErr, "capability_prepare_failed", true)
					result := failedCapabilityResultDetail(invocation, code, retryable, prepareErr.Error())
					results = replaceCapabilityResult(results, result)
					batchErr.Failures = replaceCapabilityResult(batchErr.Failures, result)
					if firstErr == nil && definition.FailurePolicy == FailurePolicyRequiredForVisibleClaim {
						firstErr = prepareErr
						batchErr.First = firstErr
					}
					continue
				}
				invocation = prepared
				invocations[index] = prepared
			}
		}
		_, transactional := capability.(TransactionalCapability)
		if deferTransactional && (executionClass == CapabilityExecutionTransactionalMutation || (executionClass == CapabilityExecutionExternalAsyncIntent && transactional)) {
			results = replaceCapabilityResult(results, CapabilityResult{CallID: invocation.CallID, CapabilityName: invocation.CapabilityName, Status: "deferred", Output: map[string]any{"reason": "transaction_pending"}, Retryable: true, ProviderRequestID: invocation.ProviderRequestID, CorrelationID: "capability:" + invocation.CallID, RequiredContext: append([]ContextSlot(nil), definition.RequiredContext...)})
			continue
		}
		if executionClass == CapabilityExecutionDeferredOutput || (executionClass == CapabilityExecutionExternalAsyncIntent && definition.IsDeferredOutput()) {
			results = replaceCapabilityResult(results, CapabilityResult{CallID: invocation.CallID, CapabilityName: invocation.CapabilityName, Status: "deferred", Output: map[string]any{"reason": "output_target_pending"}, Retryable: true, ProviderRequestID: invocation.ProviderRequestID, CorrelationID: "capability:" + invocation.CallID, RequiredContext: append([]ContextSlot(nil), definition.RequiredContext...)})
			continue
		}
		var result CapabilityResult
		var err error
		if definition.ConcurrencyClass == "exclusive" && a != nil && a.DB != nil {
			result, err = a.executeExclusiveCapabilityCanonical(ctx, fluctlightID, invocation, capability)
		} else {
			result, err = runtime.Execute(ctx, invocation)
		}
		results = replaceCapabilityResult(results, result)
		if err != nil {
			batchErr.Failures = replaceCapabilityResult(batchErr.Failures, result)
		}
		if err != nil && firstErr == nil && definition.FailurePolicy == FailurePolicyRequiredForVisibleClaim {
			firstErr = err
			batchErr.First = firstErr
		}
	}
	if persistStandaloneOutcomes {
		if persistErr := a.persistStandaloneCapabilityOutcomes(ctx, fluctlightID, invocations, results, firstErr); persistErr != nil && firstErr == nil {
			firstErr = persistErr
		}
	}
	if firstErr != nil {
		if batchErr.First == nil {
			batchErr.First = firstErr
		}
		return results, batchErr
	}
	return results, nil
}

func (a *App) prepareCapabilityInvocations(ctx context.Context, fluctlightID, conversationID, sourceFactID string, invocations []CapabilityInvocation, existing ...[]CapabilityResult) ([]CapabilityInvocation, error) {
	prepared := append([]CapabilityInvocation(nil), invocations...)
	runtime := a.capabilityRuntime()
	if runtime == nil {
		batch := &capabilityInvocationBatchError{}
		for _, invocation := range prepared {
			batch.add(invocation, ErrCapabilityNotFound, "capability_prepare_failed")
		}
		return prepared, batch
	}
	batch := &capabilityInvocationBatchError{}
	for index := range prepared {
		prepared[index] = normalizeCapabilityInvocationMetadata(prepared[index], fluctlightID, conversationID, sourceFactID, sourceFactID, index)
		if len(existing) > 0 {
			if result, found := capabilityResultForCall(existing[0], prepared[index].CallID); found && result.Status == "completed" {
				continue
			}
		}
		_, ok := runtime.Registry.Definition(prepared[index].CapabilityName)
		if !ok {
			batch.add(prepared[index], fmt.Errorf("%w: %s", ErrCapabilityNotFound, prepared[index].CapabilityName), "capability_prepare_failed")
			continue
		}
		if len(prepared[index].PreparedPayload) > 0 {
			if _, err := decodeCapabilityPreparedPayload(prepared[index].PreparedPayload); err != nil {
				batch.add(prepared[index], fmt.Errorf("%w: %v", ErrInvalidArguments, err), "capability_prepare_failed")
			}
			continue
		}
		invocation, _, err := runtime.Prepare(ctx, prepared[index])
		if err != nil {
			batch.add(prepared[index], err, "capability_prepare_failed")
			continue
		}
		prepared[index] = invocation
	}
	if len(batch.Failures) > 0 {
		return prepared, batch
	}
	return prepared, nil
}

// validateCapabilityInvocationsForPersistence performs the cheap, deterministic
// checks that are safe before an action is durable. Capability preflight and
// planner I/O intentionally stay on the action worker: a transient provider or
// renderer failure must not discard the WakeUp decision before its retryable
// action/failure record exists.
func (a *App) validateCapabilityInvocationsForPersistence(invocations []CapabilityInvocation) error {
	registry := a.capabilityRegistry()
	if registry == nil {
		return ErrCapabilityNotFound
	}
	batch := &capabilityInvocationBatchError{}
	for _, invocation := range invocations {
		definition, ok := registry.Definition(invocation.CapabilityName)
		if !ok {
			batch.add(invocation, fmt.Errorf("%w: %s", ErrCapabilityNotFound, invocation.CapabilityName), "capability_invalid")
			continue
		}
		if err := invocation.Validate(definition); err != nil {
			batch.add(invocation, err, "capability_invalid")
		}
	}
	if len(batch.Failures) > 0 {
		return batch
	}
	return nil
}

// candidateValidationContext carries the frozen identity of the candidate being
// arbitrated. It is the authority the Judge-time validator compares every
// invocation against; a Provider result cannot widen it. All checks performed
// against it are deterministic and side-effect-free — anything that needs
// network, DB or context-resolver I/O stays on the winner-only Prepare path.
type candidateValidationContext struct {
	FluctlightID   string
	ConversationID string
	SourceFactID   string
	ActionID       string
	Surface        CapabilitySurface
	// ContextSnapshot is the Core-owned snapshot captured before arbitration.
	// It is intentionally separate from CapabilityInvocation.ContextSnapshot:
	// provider supplied invocation fields are not an authority for candidate
	// authorization and are overwritten when the candidate is persisted.
	ContextSnapshot map[string]any
	// Context lets the production call sites preserve cancellation and tracing
	// while keeping the two-argument helper source compatible with existing unit
	// tests. It is never used to resolve ambient state.
	Context context.Context
}

// validateCandidateCapabilityInvocations runs the cheap persistence validator
// and then performs the deterministic authorization checks F-02 requires
// before the Judge is consulted: declared surface authorization, frozen
// identity ownership and declared output target kinds. A candidate that is
// structurally valid but unauthorized must fail here so a takeover by B cannot
// mask A's illegal invocation (request.md:79/163/296).
func (a *App) validateCandidateCapabilityInvocations(invocations []CapabilityInvocation, candidate candidateValidationContext) error {
	ctx := candidate.Context
	if ctx == nil {
		ctx = context.Background()
	}
	return a.validateCandidateCapabilityInvocationsWithContext(ctx, invocations, candidate)
}

func (a *App) validateCandidateCapabilityInvocationsWithContext(ctx context.Context, invocations []CapabilityInvocation, candidate candidateValidationContext) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if len(invocations) == 0 {
		return nil
	}
	if strings.TrimSpace(candidate.FluctlightID) == "" {
		return fmt.Errorf("%w: candidate fluctlight identity is missing", ErrUnauthorized)
	}
	if strings.TrimSpace(string(candidate.Surface)) == "" {
		return fmt.Errorf("%w: candidate surface is missing", ErrUnauthorized)
	}
	if err := ctx.Err(); err != nil {
		return fmt.Errorf("%w: candidate validation context: %v", ErrContextResolve, err)
	}
	registry := a.capabilityRegistry()
	if registry == nil {
		return ErrCapabilityNotFound
	}
	batch := &capabilityInvocationBatchError{}
	for _, invocation := range invocations {
		if err := validateCandidateCapabilityInvocation(ctx, invocation, candidate, registry); err != nil {
			batch.add(invocation, err, "candidate_invalid")
		}
	}
	if len(batch.Failures) > 0 {
		return batch
	}
	return nil
}

func validateCandidateCapabilityInvocation(ctx context.Context, invocation CapabilityInvocation, candidate candidateValidationContext, registry *CapabilityRegistry) error {
	definition, ok := registry.Definition(invocation.CapabilityName)
	if !ok {
		return fmt.Errorf("%w: %s", ErrCapabilityNotFound, invocation.CapabilityName)
	}
	if err := invocation.Validate(definition); err != nil {
		return err
	}
	if definition.InternalOnly {
		return fmt.Errorf("%w: capability %s is internal-only", ErrUnauthorized, invocation.CapabilityName)
	}
	// The frozen candidate surface is the only authority. A provider may omit
	// metadata (Core fills that default), but it may not claim another
	// already-authorized surface to widen the call's permissions.
	if declaredSurface := invocation.Metadata.Surface; declaredSurface != "" && declaredSurface != candidate.Surface {
		return fmt.Errorf("%w: capability %s declares surface %s outside candidate surface %s", ErrUnauthorized, invocation.CapabilityName, declaredSurface, candidate.Surface)
	}
	if !definition.SupportsSurface(candidate.Surface) {
		return fmt.Errorf("%w: capability %s is not authorized for surface %s", ErrUnauthorized, invocation.CapabilityName, candidate.Surface)
	}
	if owner := strings.TrimSpace(invocation.Metadata.FluctlightID); owner != "" && owner != strings.TrimSpace(candidate.FluctlightID) {
		return fmt.Errorf("%w: capability %s targets fluctlight %s outside the candidate %s", ErrUnauthorized, invocation.CapabilityName, owner, candidate.FluctlightID)
	}
	if cid := strings.TrimSpace(invocation.Metadata.ConversationID); cid != "" && cid != strings.TrimSpace(candidate.ConversationID) {
		return fmt.Errorf("%w: capability %s targets conversation %s outside the candidate %s", ErrUnauthorized, invocation.CapabilityName, cid, candidate.ConversationID)
	}
	if sourceFactID := strings.TrimSpace(invocation.SourceFactID); sourceFactID != "" && strings.TrimSpace(candidate.SourceFactID) != "" && sourceFactID != strings.TrimSpace(candidate.SourceFactID) {
		return fmt.Errorf("%w: capability %s targets source fact %s outside the candidate %s", ErrUnauthorized, invocation.CapabilityName, sourceFactID, candidate.SourceFactID)
	}
	if actionID := strings.TrimSpace(invocation.ActionID); actionID != "" && strings.TrimSpace(candidate.ActionID) != "" && actionID != strings.TrimSpace(candidate.ActionID) {
		return fmt.Errorf("%w: capability %s targets action %s outside the candidate %s", ErrUnauthorized, invocation.CapabilityName, actionID, candidate.ActionID)
	}
	if binding := invocation.Metadata.OutputBinding; binding != nil {
		if len(definition.TargetKinds) == 0 || !targetKindAuthorizes(definition.TargetKinds, binding.TargetKind) {
			return fmt.Errorf("%w: capability %s output target kind %s is not declared", ErrUnauthorized, invocation.CapabilityName, binding.TargetKind)
		}
	}

	resolved := CapabilityContext{Identity: ContextIdentity{
		FluctlightID: strings.TrimSpace(candidate.FluctlightID), ConversationID: strings.TrimSpace(candidate.ConversationID),
		SourceFactID: strings.TrimSpace(candidate.SourceFactID), ActionID: strings.TrimSpace(candidate.ActionID),
	}, extra: make(map[ContextSlot]any)}
	if len(definition.RequiredContext) > 0 {
		if len(candidate.ContextSnapshot) == 0 {
			return fmt.Errorf("%w: capability %s requires a frozen context snapshot", ErrContextResolve, invocation.CapabilityName)
		}
		if err := validateCandidateSnapshotIdentity(candidate.ContextSnapshot, candidate); err != nil {
			return fmt.Errorf("%w: capability %s: %v", ErrContextResolve, invocation.CapabilityName, err)
		}
		resolver := NewSnapshotContextResolver(candidate.ContextSnapshot)
		var resolveErr error
		resolved, resolveErr = resolver.Resolve(ctx, ContextRequest{
			FluctlightID: strings.TrimSpace(candidate.FluctlightID), ConversationID: strings.TrimSpace(candidate.ConversationID),
			SourceFactID: strings.TrimSpace(candidate.SourceFactID), ActionID: strings.TrimSpace(candidate.ActionID), Surface: candidate.Surface,
		}, definition.RequiredContext)
		if resolveErr != nil {
			return fmt.Errorf("%w: capability %s: %v", ErrContextResolve, invocation.CapabilityName, resolveErr)
		}
	} else if len(candidate.ContextSnapshot) > 0 {
		// A contextful snapshot is still checked when supplied to a contextless
		// capability so a custom hook cannot receive a forged identity.
		if err := validateCandidateSnapshotIdentity(candidate.ContextSnapshot, candidate); err != nil {
			return fmt.Errorf("%w: capability %s: %v", ErrContextResolve, invocation.CapabilityName, err)
		}
	}
	if validator, ok := registry.LookupCapability(invocation.CapabilityName); ok {
		if hook, implements := validator.(CapabilityCandidateValidator); implements {
			if err := hook.ValidateCandidate(ctx, invocation, resolved); err != nil {
				return fmt.Errorf("capability %s candidate validation: %w", invocation.CapabilityName, err)
			}
		}
	}
	return nil
}

// validateCandidateSnapshotIdentity makes the frozen snapshot binding strict
// enough for Judge-time authorization. SnapshotContextResolver intentionally
// permits legacy identity omissions for replay compatibility; a candidate
// validator cannot do that because an omitted ID would let a provider attach a
// capability to a different turn while retaining otherwise valid slot data.
func validateCandidateSnapshotIdentity(snapshot map[string]any, candidate candidateValidationContext) error {
	if len(snapshot) == 0 {
		return errors.New("snapshot is unavailable")
	}
	identity := mapValue(snapshot["identity"])
	if len(identity) == 0 {
		return errors.New("snapshot identity is missing")
	}
	checks := []struct {
		key      string
		expected string
	}{
		{"fluctlight_id", strings.TrimSpace(candidate.FluctlightID)},
		{"conversation_id", strings.TrimSpace(candidate.ConversationID)},
		{"source_fact_id", strings.TrimSpace(candidate.SourceFactID)},
	}
	for _, check := range checks {
		if check.expected == "" {
			continue
		}
		actual := strings.TrimSpace(stringValue(identity[check.key]))
		if actual == "" {
			return fmt.Errorf("snapshot identity %s is missing", check.key)
		}
		if actual != check.expected {
			return fmt.Errorf("snapshot identity %s does not match candidate", check.key)
		}
	}
	if expectedAction := strings.TrimSpace(candidate.ActionID); expectedAction != "" {
		if actualAction := strings.TrimSpace(stringValue(identity["action_id"])); actualAction != "" && actualAction != expectedAction {
			return errors.New("snapshot identity action_id does not match candidate")
		}
	}
	return nil
}

func targetKindAuthorizes(declared []string, kind string) bool {
	for _, allowed := range declared {
		if allowed == kind {
			return true
		}
	}
	return false
}

func (a *App) bindCapabilityInvocationsToProjection(invocations []CapabilityInvocation, projection ContextProjection, actionID, sourceFactID string, surface CapabilitySurface) ([]CapabilityInvocation, error) {
	bound := append([]CapabilityInvocation(nil), invocations...)
	registry := a.capabilityRegistry()
	batch := &capabilityInvocationBatchError{}
	for index := range bound {
		bound[index] = normalizeCapabilityInvocationMetadata(bound[index], projection.FluctlightID, projection.ConversationID, sourceFactID, sourceFactID, index)
		bound[index].ActionID = actionID
		bound[index].Metadata.Surface = surface
		definition, ok := registry.Definition(bound[index].CapabilityName)
		if !ok {
			batch.add(bound[index], fmt.Errorf("%w: %s", ErrCapabilityNotFound, bound[index].CapabilityName), "capability_bind_failed")
			continue
		}
		bound[index].ContextSnapshot = capabilitySnapshotForProjection(projection, definition.RequiredContext, actionID)
	}
	if len(batch.Failures) > 0 {
		return bound, batch
	}
	return bound, nil
}

func normalizeCapabilityInvocationMetadata(invocation CapabilityInvocation, fluctlightID, conversationID, sourceFactID, identityScope string, sequence int) CapabilityInvocation {
	if invocation.CallID == "" {
		return invocation
	}
	if invocation.SourceFactID == "" {
		invocation.SourceFactID = sourceFactID
	}
	if invocation.ProviderRequestID == "" {
		invocation.ProviderRequestID = "provider:" + stableDigest(identityScope+":"+invocation.CallID)
	}
	if invocation.Sequence < 0 {
		invocation.Sequence = sequence
	}
	if invocation.Metadata.FluctlightID == "" {
		invocation.Metadata.FluctlightID = fluctlightID
	}
	if invocation.Metadata.ConversationID == "" {
		invocation.Metadata.ConversationID = conversationID
	}
	if invocation.Metadata.Surface == "" {
		invocation.Metadata.Surface = CapabilitySurfaceConversation
	}
	if invocation.Intent == "" {
		var args map[string]any
		if json.Unmarshal(invocation.Arguments, &args) == nil {
			invocation.Intent = stringValue(args["intent"])
		}
	}
	if invocation.SchemaVersion == "" {
		invocation.SchemaVersion = CapabilityInvocationSchemaVersion
	}
	return invocation
}

func (a *App) executeExclusiveCapabilityCanonical(ctx context.Context, fluctlightID string, invocation CapabilityInvocation, capability Capability) (CapabilityResult, error) {
	conn, err := a.DB.Pool().Acquire(ctx)
	if err != nil {
		return failedCapabilityResultDetail(invocation, "capability_busy", true, err.Error()), err
	}
	defer conn.Release()
	var acquired bool
	lockKey := "capability:" + fluctlightID + ":" + invocation.CapabilityName
	if err := conn.QueryRow(ctx, `SELECT pg_try_advisory_lock(hashtext($1))`, lockKey).Scan(&acquired); err != nil {
		return failedCapabilityResultDetail(invocation, "capability_busy", true, err.Error()), err
	}
	if !acquired {
		return failedCapabilityResultDetail(invocation, "capability_busy", true, "capability is already running"), errors.New("capability_busy")
	}
	defer func() {
		unlockCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), time.Second)
		defer cancel()
		_, _ = conn.Exec(unlockCtx, `SELECT pg_advisory_unlock(hashtext($1))`, lockKey)
	}()
	return a.capabilityRuntime().Execute(ctx, invocation)
}

func requiredCapabilityFailureCanonical(results []CapabilityResult, invocations []CapabilityInvocation, registry *CapabilityRegistry, settled bool) error {
	if registry == nil {
		return newCapabilityError("capability_not_found", false, fmt.Errorf("%w: registry is unavailable", ErrCapabilityNotFound))
	}
	for _, invocation := range invocations {
		definition, ok := registry.Definition(invocation.CapabilityName)
		if !ok {
			return newCapabilityError("capability_not_found", false, fmt.Errorf("required capability %q is unavailable", invocation.CapabilityName))
		}
		if definition.FailurePolicy != FailurePolicyRequiredForVisibleClaim {
			continue
		}
		// Failure policy is scoped to a capability's own output contract. In a
		// multi-call batch only a primary visible output (conversation message or
		// Moment) may fail the caller-owned settlement. Media, state, memory, and
		// other siblings retain their own failed result without rolling back a
		// successful sibling.
		if len(invocations) > 1 && definition.OutputRole != "conversation_message" && definition.OutputRole != "moment" {
			continue
		}
		result, found := capabilityResultForCall(results, invocation.CallID)
		if !found {
			return newCapabilityError("capability_result_missing", false, fmt.Errorf("required capability %q has no result", invocation.CapabilityName))
		}
		if result.CallID != invocation.CallID || result.CapabilityName != invocation.CapabilityName {
			return newCapabilityError("capability_result_identity_mismatch", false, fmt.Errorf("required capability %q result identity mismatch", invocation.CapabilityName))
		}
		if result.Status == "failed" || result.Status == "rejected" || (settled && result.Status != "completed") {
			code := result.ErrorCode
			if code == "" {
				code = "capability_execution_failed"
			}
			return newCapabilityError(code, result.Retryable, fmt.Errorf("required capability %q failed", invocation.CapabilityName))
		}
		if !settled && result.Status != "completed" && result.Status != "deferred" {
			return newCapabilityError("capability_result_status_invalid", false, fmt.Errorf("required capability %q returned invalid status %q", invocation.CapabilityName, result.Status))
		}
	}
	return nil
}

// requiredVisibleOutputCapabilityFailure is the conversation settlement gate.
// It protects the one capability that can make a visible assistant claim
// (conversation_message) while deliberately ignoring failures from independent
// media/state/memory siblings. Their own CapabilityResult remains durable and
// is retried or diagnosed by its own worker policy; it cannot turn a valid
// private reply into a browser retry.
func requiredVisibleOutputCapabilityFailure(results []CapabilityResult, invocations []CapabilityInvocation, registry *CapabilityRegistry, settled bool) error {
	return requiredOutputCapabilityFailure(results, invocations, registry, settled, "conversation_message")
}

func requiredOutputCapabilityFailure(results []CapabilityResult, invocations []CapabilityInvocation, registry *CapabilityRegistry, settled bool, targetKind string) error {
	if registry == nil {
		return newCapabilityError("capability_not_found", false, fmt.Errorf("%w: registry is unavailable", ErrCapabilityNotFound))
	}
	visible := make([]CapabilityInvocation, 0, len(invocations))
	for _, invocation := range invocations {
		definition, ok := registry.Definition(invocation.CapabilityName)
		if !ok {
			continue
		}
		if definition.OutputRole == targetKind {
			visible = append(visible, invocation)
		}
	}
	if len(visible) == 0 {
		return nil
	}
	return requiredCapabilityFailureCanonical(results, visible, registry, settled)
}

func capabilityFailureInfo(err error, results []CapabilityResult, invocations []CapabilityInvocation, registry *CapabilityRegistry, fallbackCode string) (string, bool) {
	code, retryable := capabilityErrorInfo(err, fallbackCode, true)
	if errors.Is(err, ErrCapabilityNotFound) || errors.Is(err, ErrInvalidArguments) || errors.Is(err, ErrConflict) {
		retryable = false
	}
	resultByCall := make(map[string]CapabilityResult, len(results))
	for _, result := range results {
		resultByCall[result.CallID] = result
	}
	for _, invocation := range invocations {
		definition, found := registry.Definition(invocation.CapabilityName)
		if !found || definition.FailurePolicy != FailurePolicyRequiredForVisibleClaim {
			continue
		}
		result, found := resultByCall[invocation.CallID]
		if !found || (result.Status != "failed" && result.Status != "rejected") {
			continue
		}
		if strings.TrimSpace(result.ErrorCode) != "" {
			code = strings.TrimSpace(result.ErrorCode)
		}
		if !result.Retryable {
			return code, false
		}
	}
	return code, retryable
}

func stringSliceAny(values []string) []any {
	result := make([]any, len(values))
	for index, value := range values {
		result[index] = value
	}
	return result
}

// settleDeferredCapabilitiesTx performs the output-target phase for canonical
// invocations. It runs INSIDE the caller's settlement transaction: a
// transactional mutation is applied through a savepoint so a single failure
// cannot poison the surrounding settlement, and every deferred invocation
// yields a result, including bounded failures.
//
// Deferred capabilities are side-effect-scoped to this row by contract: they
// write their own persistence rows and register an intent, and they must not
// perform network IO here. Actual external execution happens after commit,
// driven by the outbox / workflow workers. The Preflight* family follows the
// same rule — Preflight speaks to the runtime configuration cache and
// PreflightTx reads the same configuration from the transaction (see
// preflightImageCapabilityTx), so neither performs the external call.
func (a *App) settleDeferredCapabilitiesTx(ctx context.Context, tx pgx.Tx, fluctlightID, sourceFactID, identityScope string, invocations []CapabilityInvocation, existing []CapabilityResult, binding OutputBindingV1) ([]CapabilityResult, error) {
	results := append([]CapabilityResult(nil), existing...)
	if len(invocations) == 0 {
		return results, nil
	}
	runtime := a.capabilityRuntime()
	if runtime == nil {
		for _, invocation := range invocations {
			results = replaceCapabilityResult(results, failedCapabilityResultDetail(invocation, "capability_not_found", false, "capability runtime is unavailable"))
		}
		return results, ErrCapabilityNotFound
	}
	for index := range invocations {
		invocation := normalizeCapabilityInvocationMetadata(invocations[index], fluctlightID, "", sourceFactID, identityScope, index)
		invocations[index] = invocation
		definition, ok := runtime.Registry.Definition(invocation.CapabilityName)
		if !ok {
			results = replaceCapabilityResult(results, failedCapabilityResultDetail(invocation, "capability_not_found", false, invocation.CapabilityName))
			continue
		}
		capability, found := runtime.Registry.LookupCapability(invocation.CapabilityName)
		if !found {
			results = replaceCapabilityResult(results, failedCapabilityResultDetail(invocation, "capability_not_found", false, "implementation is not registered"))
			continue
		}
		executionClass, classErr := classifyCapabilityExecution(capability, definition)
		if classErr != nil {
			results = replaceCapabilityResult(results, failedCapabilityResultDetail(invocation, "capability_execution_class_invalid", false, classErr.Error()))
			continue
		}
		_, transactional := capability.(TransactionalCapability)
		if executionClass != CapabilityExecutionTransactionalMutation && executionClass != CapabilityExecutionDeferredOutput && !(executionClass == CapabilityExecutionExternalAsyncIntent && (definition.IsDeferredOutput() || transactional)) {
			results = replaceCapabilityResult(results, failedCapabilityResultDetail(invocation, "capability_execution_class_invalid", false, "capability is not executable in the settlement phase"))
			continue
		}
		if existingResult, found := capabilityResultForCall(results, invocation.CallID); found && (existingResult.Status == "completed" || existingResult.Status == "failed" || existingResult.Status == "rejected") {
			continue
		}
		if definition.IsDeferredOutput() && binding.TargetKind == "" {
			results = replaceCapabilityResult(results, failedCapabilityResultDetail(invocation, "output_binding_required", false, "deferred output capability requires a concrete target binding"))
			continue
		}
		var result CapabilityResult
		var err error
		if transactional {
			applyTx := tx
			var savepoint pgx.Tx
			if tx != nil {
				savepoint, err = tx.Begin(ctx)
				if err == nil {
					applyTx = savepoint
				}
			}
			if err == nil {
				result, err = runtime.ExecuteTransactional(ctx, applyTx, invocation)
			}
			if savepoint != nil {
				if err != nil {
					_ = savepoint.Rollback(ctx)
				} else if commitErr := savepoint.Commit(ctx); commitErr != nil {
					err = commitErr
				}
			}
		} else {
			callBinding := binding
			callBinding.ToolCallID = invocation.CallID
			invocation.Metadata.OutputBinding = &callBinding
			invocations[index] = invocation
			result, err = runtime.ExecuteDeferred(ctx, tx, invocation, callBinding)
		}
		if err != nil {
			// ExecuteDeferred already normalizes identity/status, but make the
			// transaction boundary fail-closed even for a faulty implementation.
			result.CallID = invocation.CallID
			result.CapabilityName = invocation.CapabilityName
			result.Status = "failed"
			if result.ErrorCode == "" {
				result.ErrorCode, result.Retryable = capabilityErrorInfo(err, "capability_execution_failed", true)
			}
		}
		if result.ProviderRequestID == "" {
			result.ProviderRequestID = invocation.ProviderRequestID
		}
		if result.CorrelationID == "" {
			result.CorrelationID = "capability:" + invocation.CallID
		}
		if result.Status == "completed" {
			if validationErr := definition.ValidateOutput(result.Output); validationErr != nil {
				result = failedCapabilityResultDetail(invocation, "capability_output_invalid", false, validationErr.Error())
			}
		}
		results = replaceCapabilityResult(results, result)
	}
	return results, nil
}

func capabilityResultForCall(results []CapabilityResult, callID string) (CapabilityResult, bool) {
	for _, result := range results {
		if result.CallID == callID {
			return result, true
		}
	}
	return CapabilityResult{}, false
}

func replaceCapabilityResult(results []CapabilityResult, replacement CapabilityResult) []CapabilityResult {
	for index := range results {
		if results[index].CallID == replacement.CallID {
			results[index] = replacement
			return results
		}
	}
	return append(results, replacement)
}

// capabilityResultsAfterSettlementFailure converts any output-target result
// that could not be committed into an explicit failed result. A transaction
// rollback means that even a capability which returned completed did not leave
// its durable target behind; replay must therefore retry/quarantine it instead
// of treating the provisional result as success.
func capabilityResultsAfterSettlementFailure(results []CapabilityResult, invocations []CapabilityInvocation, registry *CapabilityRegistry, code string) []CapabilityResult {
	if code == "" {
		code = "capability_settlement_failed"
	}
	settled := append([]CapabilityResult(nil), results...)
	if registry == nil {
		for _, invocation := range invocations {
			settled = replaceCapabilityResult(settled, failedCapabilityResult(invocation, code, true))
		}
		return settled
	}
	for _, invocation := range invocations {
		definition, ok := registry.Definition(invocation.CapabilityName)
		capability, capabilityFound := registry.LookupCapability(invocation.CapabilityName)
		_, transactional := capability.(TransactionalCapability)
		if !ok || (!definition.IsDeferredOutput() && (!capabilityFound || !transactional)) {
			continue
		}
		result, found := capabilityResultForCall(settled, invocation.CallID)
		if found && result.Status == "completed" {
			result.Status = "failed"
			result.ErrorCode = code
			result.Retryable = true
			result.CallID = invocation.CallID
			result.CapabilityName = invocation.CapabilityName
			if result.ProviderRequestID == "" {
				result.ProviderRequestID = invocation.ProviderRequestID
			}
			settled = replaceCapabilityResult(settled, result)
			continue
		}
		if !found || result.Status == "deferred" {
			settled = replaceCapabilityResult(settled, failedCapabilityResult(invocation, code, true))
		}
	}
	return settled
}

func capabilityResultsFromValue(value any) ([]CapabilityResult, error) {
	if value == nil {
		return []CapabilityResult{}, nil
	}
	data, err := json.Marshal(value)
	if err != nil {
		return nil, fmt.Errorf("capability result payload invalid: %w", err)
	}
	if string(data) == "null" {
		return []CapabilityResult{}, nil
	}
	var results []CapabilityResult
	if err := json.Unmarshal(data, &results); err != nil {
		return nil, fmt.Errorf("capability result payload invalid: %w", err)
	}
	seen := make(map[string]struct{}, len(results))
	for index := range results {
		if strings.TrimSpace(results[index].CallID) == "" || strings.TrimSpace(results[index].CapabilityName) == "" {
			return nil, fmt.Errorf("capability result %d identity is missing", index)
		}
		if _, duplicate := seen[results[index].CallID]; duplicate {
			return nil, fmt.Errorf("capability result %d call id is duplicated", index)
		}
		seen[results[index].CallID] = struct{}{}
		switch results[index].Status {
		case "completed", "failed", "rejected", "deferred":
		default:
			return nil, fmt.Errorf("capability result %d status is invalid", index)
		}
	}
	return results, nil
}

func mediaIntentIDFromCapabilityResults(results []CapabilityResult) string {
	for _, result := range results {
		if result.Status != "completed" {
			continue
		}
		if output := mapValue(result.Output); len(output) > 0 {
			if id := stringValue(output["media_intent_id"]); id != "" {
				return id
			}
		}
	}
	return ""
}

func hasConversationReplyCapability(invocations []CapabilityInvocation, registry *CapabilityRegistry) bool {
	for _, invocation := range invocations {
		if isConversationReplyInvocation(invocation, registry) {
			return true
		}
	}
	return false
}

func replyTextFromCapabilityInvocations(invocations []CapabilityInvocation, registry *CapabilityRegistry) string {
	for _, invocation := range invocations {
		if !isConversationReplyInvocation(invocation, registry) {
			continue
		}
		var args map[string]any
		if json.Unmarshal(invocation.Arguments, &args) != nil {
			continue
		}
		if text := normalizeVisibleReply(stringValue(args["text"])); text != "" {
			return text
		}
	}
	return ""
}

// isConversationReplyInvocation identifies the one built-in visible-output
// capability by its canonical name. A normal runtime registry still verifies
// the declared output role; when a partially assembled registry is used (for
// example while recovering a diagnostic/frozen payload), the canonical name is
// enough to preserve the reply text instead of letting unrelated structured
// fields turn a valid private message into an empty response.
func isConversationReplyInvocation(invocation CapabilityInvocation, registry *CapabilityRegistry) bool {
	if strings.TrimSpace(invocation.CapabilityName) != conversationReplyCapabilityName {
		return false
	}
	if registry == nil {
		return true
	}
	definition, ok := registry.Definition(invocation.CapabilityName)
	if !ok {
		return true
	}
	return definition.OutputRole == "conversation_message"
}

func resolveCapabilityAction(invocations []CapabilityInvocation, definitions map[string]CapabilityDefinition) (string, error) {
	if len(invocations) == 0 {
		return "", errors.New("at least one capability invocation is required")
	}
	for _, invocation := range invocations {
		definition, ok := definitions[invocation.CapabilityName]
		if !ok {
			continue
		}
		if invocation.Metadata.OutputBinding != nil && invocation.Metadata.OutputBinding.TargetKind == "conversation_message" {
			return "reply", nil
		}
		if definition.OutputRole == "conversation_message" {
			return "reply", nil
		}
	}
	return "no_op", nil
}
