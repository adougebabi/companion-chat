<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { mountProduct } from './v3/proto/app';
const host = ref<HTMLElement | null>(null);
onMounted(() => { void mountProduct(host.value); });
</script>
<template><div id="v3-root" ref="host" /></template>
