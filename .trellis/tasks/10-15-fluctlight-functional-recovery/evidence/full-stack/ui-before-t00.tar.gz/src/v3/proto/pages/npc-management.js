import * as store from '../store.js';
import { esc, icon, badge, toast, confirm, requireOwner, drawer, modal, objLink, nameOf } from '../ui.js';
import { Button, Field, SearchForm, DiffView } from '../components/forms.js';
import { Card, EmptyState, EntityHeader } from '../components/cards.js';
import { RoutineEditor, PositionSummary } from '../components/routine.js';
import { ConflictPanel } from '../components/revisions.js';
import { mockClient } from '../mock/client.js';

const drafts = new Map();
store.subscribe(event => { if (event.type === 'reset') drafts.clear(); });
const placeOptions = characterId => store.list('places', place => place.worldId === store.get('characters', characterId).worldId);

export function renderNPCManagement(el, ctx) {
  let alive = true;
  async function paint() {
    const people = await mockClient.npcs(ctx.charId, { query: ctx.query.q || '', archived: ctx.query.archived === '1' }); if (!alive) return;
    el.innerHTML = `${SearchForm({ value: ctx.query.q || '', placeholder: '搜索当前运行世界的姓名或身份', attrs: { 'data-npc-search': true } })}<div class="row" style="margin:12px 0"><a class="btn primary" href="#/c/${ctx.charId}/people/npc/new">${icon('plus')} 新建 NPC 定义</a><a class="btn" href="#/c/${ctx.charId}/people/npcs?archived=${ctx.query.archived === '1' ? '0' : '1'}">${ctx.query.archived === '1' ? '只看启用人物' : '包含已归档人物'}</a><a class="btn ghost" href="#/c/${ctx.charId}/people/list">返回人物目录</a></div>
      <div class="card">${people.length ? people.map(npc => `<div class="lrow"><img class="av sm" src="${esc(npc.avatar)}" alt=""><div class="grow"><b>${esc(npc.name)}</b><div class="small muted">${esc(npc.role)} · ${esc(nameOf(npc.placeId) || '初始地点未设定')}</div></div>${badge(npc.archived ? '已归档' : npc.enabled === false ? '不出现' : '启用', 'plain')}<a class="btn sm" href="#/c/${ctx.charId}/people/npc/${npc.id}">详情</a><a class="btn sm" href="#/c/${ctx.charId}/people/npc/${npc.id}/edit">编辑</a></div>`).join('') : EmptyState({ title: '当前范围未找到人物', text: '可以清除筛选，或先创作 NPC 定义并应用到当前世界。' })}</div>
      <div class="banner info small" style="margin-top:12px">${badge('Mock', 'plain')} 创建定义、应用到运行世界、已经结识是不同状态。管理目录不会偷偷生成关系或交往记录。</div>`;
    el.querySelector('[data-npc-search]').onsubmit = event => { event.preventDefault(); ctx.navigate(`#/c/${ctx.charId}/people/npcs?q=${encodeURIComponent(event.target.q.value)}&archived=${ctx.query.archived || '0'}`); };
  }
  void paint().catch(error => { if (alive) el.innerHTML = EmptyState({ title: error.message }); });
  return () => { alive = false; };
}

export function renderNPCDefinition(el, ctx) {
  let alive = true, resourceId = ctx.params.resId || null;
  const key = resourceId || `new:${ctx.charId}`;
  const existing = resourceId && store.get('resources', resourceId);
  if (resourceId && (!existing || existing.type !== 'NPC')) { el.innerHTML = EmptyState({ title: '未找到 NPC 定义', actions: '<a class="btn" href="#/studio">创作中心</a>' }); return; }
  if (!drafts.has(key)) { const value = existing?.draft || existing?.versions[existing.published] || {}; drafts.set(key, { name: value.名称 || ctx.query.name || '', role: value.简介 || '', bio: value.背景 || '', placeId: '', charId: ctx.charId, dirty: false }); }
  const draft = drafts.get(key);
  if (store.get('characters', draft.charId)?.status === '已退休' || !store.get('characters', draft.charId)?.worldId) { draft.charId = 'c1'; draft.placeId = ''; }
  function paint() {
    if (!alive) return; const resource = resourceId && store.get('resources', resourceId), published = resource?.versions[resource.published];
    el.innerHTML = `<div class="studio"><div class="stack"><div class="card"><div class="row"><span class="typeicon">${icon('people')}</span><div class="grow"><h2 style="margin:0">${esc(resource?.name || '新建 NPC 定义')}</h2><div class="small muted">NPC · ${resource?.published ? `已发布 ${resource.published}` : '尚未发布'}${draft.dirty ? ' · 有未保存修改' : ''}</div></div>${badge('全局定义')}</div><div class="banner info small" style="margin-top:8px">定义不等于完整摇光。发布不会自动把人物放进世界，也不会自动结识。</div></div>
      <form class="card stack" data-definition>${Field({ label: '名称', name: 'name', value: draft.name, attrs: { required: true, maxlength: 200, 'data-draft': 'name' } })}${Field({ label: '身份 / 简介', name: 'role', value: draft.role, attrs: { maxlength: 512, 'data-draft': 'role' } })}${Field({ label: '背景', name: 'bio', value: draft.bio, type: 'textarea', attrs: { maxlength: 8000, 'data-draft': 'bio' } })}<div class="btngroup"><button class="btn" data-test="npc-save-draft">保存草稿</button>${Button({ label: '发布定义', tone: 'primary', attrs: { 'data-publish-npc': true, disabled: !resource?.draft || draft.dirty } })}${Button({ label: '放弃修改', tone: 'danger', attrs: { 'data-discard-npc': true } })}</div></form>
      <div class="card"><h3>差异预览</h3>${DiffView([{ field: '名称', before: published?.名称 || '尚未发布', after: draft.name }, { field: '简介', before: published?.简介 || '', after: draft.role }, { field: '背景', before: published?.背景 || '', after: draft.bio }])}</div></div>
      <div class="stack"><div class="card"><h3>应用到运行世界</h3><p class="small muted">只应用已经发布的版本。每个运行世界创建独立人物，关系与记忆不会因应用而产生。</p>${Field({ label: '目标角色 / 世界', name: 'charId', value: draft.charId, type: 'select', options: store.list('characters', character => character.status !== '已退休' && character.worldId).map(character => ({ value: character.id, label: `${character.name} · ${store.get('worlds', character.worldId)?.name || '无世界'}` })), attrs: { 'data-target-char': true } })}${Field({ label: '初始地点', name: 'placeId', value: draft.placeId, type: 'select', options: [{ value: '', label: '未设定' }, ...placeOptions(draft.charId).map(place => ({ value: place.id, label: place.name }))], attrs: { 'data-target-place': true } })}<div class="row" style="margin-top:12px">${Button({ label: '确认应用到世界', tone: 'primary', attrs: { 'data-apply-npc': true, disabled: !resource?.published } })}</div></div>
      <div class="card"><h3>版本与边界</h3><p>草稿：${resource?.draft ? '已保存，尚未发布' : '无草稿'}；已发布：${esc(resource?.published || '无')}。</p><p class="small muted">本阶段全部是 Mock 数据。人物生活规律和位置模式在应用后的独立人物详情中编辑。</p><a class="btn" href="#/c/${ctx.charId}/people/npcs">NPC 管理</a><a class="btn ghost" href="#/studio">创作中心</a></div></div></div>`;
    el.querySelectorAll('[data-draft]').forEach(input => input.oninput = () => { draft[input.dataset.draft] = input.value; draft.dirty = true; el.querySelector('[data-publish-npc]').disabled = true; });
    el.querySelector('[data-definition]').onsubmit = async event => {
      event.preventDefault(); if (!(await requireOwner())) return;
      try { if (!resourceId) { const value = await mockClient.createNPCDraft(ctx.charId, draft); resourceId = value.id; draft.dirty = false; drafts.set(resourceId, draft); drafts.delete(key); ctx.navigate(`#/studio/npc/${resourceId}`); }
        else { await mockClient.saveNPCDraft(resourceId, draft); draft.dirty = false; paint(); toast('NPC 草稿已保存（Mock，未发布）', 'ok'); } }
      catch (error) { toast(error.message, 'err'); }
    };
    el.querySelector('[data-publish-npc]').onclick = async () => { if (!(await requireOwner())) return; if (!(await confirm({ title: '发布 NPC 定义', text: '发布保存的草稿；不会改变任何运行世界。' }))) return; try { await mockClient.publishNPCDraft(resourceId); draft.dirty = false; paint(); toast('定义已发布（Mock，尚未应用）', 'ok'); } catch (error) { toast(error.message, 'err'); } };
    el.querySelector('[data-discard-npc]').onclick = () => { drafts.delete(resourceId || key); ctx.refresh(); };
    el.querySelector('[data-target-char]').onchange = event => { draft.charId = event.target.value; draft.placeId = ''; paint(); };
    el.querySelector('[data-target-place]').onchange = event => { draft.placeId = event.target.value; };
    el.querySelector('[data-apply-npc]').onclick = async () => { const existingNPC = store.list('npcs', npc => npc.charId === draft.charId && npc.resourceId === resourceId)[0]; if (existingNPC) { await npcApplyDrawer(resourceId, draft.charId); return; } if (!(await requireOwner())) return; if (!(await confirm({ title: '应用 NPC 到运行世界', text: '建立独立的运行人物。此操作不移动角色，也不产生已经结识的关系。' }))) return; try { const npc = await mockClient.applyNPC(draft.charId, resourceId, draft.placeId); ctx.navigate(`#/c/${draft.charId}/people/npc/${npc.id}`); toast('已应用到世界（Mock，尚未结识）', 'ok'); } catch (error) { toast(error.message, 'err'); } };
  }
  paint(); return () => { alive = false; };
}

export function renderNPCEditor(el, ctx) {
  let alive = true; const id = ctx.params.npcId, key = `npc:${ctx.charId}:${id}`;
  async function paint() {
    const npc = await mockClient.npc(ctx.charId, id); if (!alive) return;
    if (!drafts.has(key)) drafts.set(key, { ...structuredClone(npc), base: npc.version, conflict: false });
    const draft = drafts.get(key), places = placeOptions(ctx.charId);
    el.innerHTML = `<div class="grid g2" style="align-items:start"><form class="card stack" data-npc-form>${EntityHeader({ avatar: npc.avatar, title: npc.name, subtitle: '运行人物 · 当前世界的局部资料', status: badge(npc.archived ? '已归档' : '启用', 'plain') })}
      ${draft.conflict ? ConflictPanel({ baseVersion: draft.base, currentVersion: npc.version }) : ''}${Field({ label: '姓名', name: 'name', value: draft.name, attrs: { required: true, 'data-npc-field': 'name' } })}${Field({ label: '身份 / 简介', name: 'role', value: draft.role, attrs: { 'data-npc-field': 'role' } })}${Field({ label: '背景', name: 'bio', value: draft.bio, type: 'textarea', attrs: { 'data-npc-field': 'bio' } })}${Field({ label: '初始 / 默认地点', name: 'placeId', value: draft.placeId, type: 'select', options: [{ value: '', label: '未设定' }, ...places.map(place => ({ value: place.id, label: place.name }))], attrs: { 'data-npc-field': 'placeId' } })}${Field({ label: '位置模式', name: 'positionMode', value: draft.positionMode || '默认地点', type: 'select', options: ['默认地点', '按生活规律推算', '固定地点'], attrs: { 'data-npc-field': 'positionMode' } })}
      <label class="toggle"><input name="enabled" type="checkbox" ${draft.enabled !== false ? 'checked' : ''}> 在世界里出现（Mock）</label><label class="toggle"><input name="archived" type="checkbox" ${draft.archived ? 'checked' : ''}> 归档并保留所有历史引用</label><div class="row"><button class="btn primary">保存人物资料</button>${Button({ label: '放弃草稿', attrs: { 'data-reset-npc': true } })}<a class="btn ghost" href="#/c/${ctx.charId}/people/npc/${id}">返回详情</a></div></form>
      <div class="stack"><div class="card"><h3>生活规律</h3><p class="small muted">这是计划推算，不是已发生的位置事实；不会建设独立 NPC 模型循环。</p>${RoutineEditor({ slots: draft.routine || [], places })}</div><div class="card"><h3>位置与来源</h3>${PositionSummary({ npc, placeName: value => nameOf(value) || '未设定' })}<p class="small muted">当前 Mock 版本 v${npc.version}。创建人物不代表已经认识。</p>${Button({ label: '移除无引用人物', tone: 'danger', attrs: { 'data-remove-npc': true, disabled: npc.references.length > 0, title: npc.references.length ? '人物被关系或记忆引用，请使用归档' : '仅移除没有历史引用的人物' } })}${npc.references.length ? `<p class="small muted">引用：${npc.references.map(ref => objLink(ref)).join('、')}</p>` : ''}</div></div></div>`;
    el.querySelectorAll('[data-npc-field]').forEach(input => input.oninput = input.onchange = () => { draft[input.dataset.npcField] = input.value; });
    el.querySelector('[name=enabled]').onchange = event => { draft.enabled = event.target.checked; };
    el.querySelector('[name=archived]').onchange = event => { draft.archived = event.target.checked; };
    el.querySelector('[data-npc-form]').onsubmit = async event => { event.preventDefault(); if (!(await requireOwner())) return; const form = event.target; draft.enabled = form.enabled.checked; draft.archived = form.archived.checked;
      try { const saved = await mockClient.saveNPC(ctx.charId, id, { ...draft, expectedVersion: draft.base }); drafts.set(key, { ...saved, base: saved.version, conflict: false }); await paint(); toast('人物资料已保存（Mock，关系未改变）', 'ok'); }
      catch (error) { if (error.status === 409) { draft.conflict = true; await paint(); } else toast(error.message, 'err'); }
    };
    el.querySelector('[data-reset-npc]').onclick = () => { drafts.delete(key); void paint(); };
    el.querySelector('[data-keep]')?.addEventListener('click', () => toast('草稿已保留'));
    el.querySelector('[data-refresh]')?.addEventListener('click', () => { draft.base = npc.version; draft.conflict = false; void paint(); });
    el.querySelector('[data-add-slot]').onclick = () => { (draft.routine ||= []).push({ day: '每天', start: '09:00', end: '17:00', placeId: '', activity: '' }); void paint(); };
    el.querySelectorAll('[data-slot]').forEach(row => { const index = Number(row.dataset.slot); row.querySelectorAll('input,select').forEach(input => input.onchange = input.oninput = () => { const field = input.name.split('_')[0]; draft.routine[index][field === 'place' ? 'placeId' : field] = input.value; }); });
    el.querySelectorAll('[data-remove-slot]').forEach(button => button.onclick = () => { draft.routine.splice(Number(button.dataset.removeSlot), 1); void paint(); });
    el.querySelector('[data-remove-npc]').onclick = async () => { if (!(await requireOwner())) return; if (!(await confirm({ title: '移除无引用 NPC', text: '仅从当前 Mock 运行世界移除，不删除定义。' }))) return; try { await mockClient.removeNPC(ctx.charId, id); drafts.delete(key); ctx.navigate(`#/c/${ctx.charId}/people/npcs`); } catch (error) { toast(error.message, 'err'); } };
  }
  void paint().catch(error => { if (alive) el.innerHTML = EmptyState({ title: error.message }); }); return () => { alive = false; };
}

export async function npcApplyDrawer(resourceId, characterId) {
  const resource = store.get('resources', resourceId), instance = store.get('instances')[characterId]?.[resourceId];
  if (!instance?.npcId) return;
  const npc = await mockClient.npc(characterId, instance.npcId), target = resource.versions[resource.published], choices = {};
  const fields = [['name', '名称'], ['role', '简介'], ['bio', '背景']];
  const d = drawer({ title: '应用 NPC 新版本 · Mock', body: `<p>${esc(npc.name)} · ${esc(instance.applied)} → ${esc(resource.published)}</p>${DiffView(fields.map(([field, key]) => ({ field: key, before: npc[field], after: target[key] })))}${Object.keys(instance.overrides).map(key => Field({ label: key + '已有局部修正', name: key, value: 'keep', type: 'select', options: [{ value: 'keep', label: '保留局部修正' }, { value: 'replace', label: '使用新定义' }], attrs: { 'data-choice': key } })).join('')}<p class="small muted">关系、经历、地点、生活规律都保留；这不会把人物变成已结识。</p><div data-apply-error role="alert"></div>`, footer: Button({ label: '确认应用新定义', tone: 'primary', attrs: { 'data-apply-version': true, disabled: instance.applied === resource.published } }) });
  d.el.querySelectorAll('[data-choice]').forEach(input => input.onchange = () => { choices[input.dataset.choice] = input.value; });
  d.el.querySelector('[data-apply-version]').onclick = async () => { if (!(await requireOwner())) return; try { await mockClient.updateNPCDefinition(characterId, npc.id, { expectedVersion: npc.version, choices }); drafts.delete(`npc:${characterId}:${npc.id}`); d.close(); toast('NPC 新版本已应用（Mock）', 'ok'); } catch (error) { d.el.querySelector('[data-apply-error]').textContent = error.message; } };
  return d;
}

export function encounterDrawer(characterId, npcId) {
  const places = placeOptions(characterId), npc = store.get('npcs', npcId);
  const d = modal({ title: '有来源的接触 · Mock 演示', body: `<p class="small muted">演示一次与${esc(npc.name)}的接触。仅创建隔离的 Mock 事件，不移动角色。</p><form class="stack" data-encounter>${Field({ label: '接触地点', name: 'placeId', value: npc.placeId || '', type: 'select', options: [{ value: '', label: '选择当前世界地点' }, ...places.map(place => ({ value: place.id, label: place.name }))] })}${Field({ label: '发生经过', name: 'summary', type: 'textarea', value: '' })}<label class="toggle"><input name="establish" type="checkbox"> 根据这次接触建立熟人记录（Mock）</label></form><p data-encounter-error role="alert"></p>`, footer: Button({ label: '确认演示接触', tone: 'primary', attrs: { 'data-encounter-confirm': true } }) });
  d.el.querySelector('[data-encounter-confirm]').onclick = async () => { const form = d.el.querySelector('[data-encounter]'); try { if (!(await requireOwner())) return; const result = await mockClient.recordEncounter(characterId, npcId, { placeId: form.placeId.value, summary: form.summary.value, establishRelation: form.establish.checked }); d.close(); toast('Mock 接触已记录；来源可在事件详情查看', 'ok'); location.hash = `#/c/${characterId}/world/event/${result.eventId}`; } catch (error) { d.el.querySelector('[data-encounter-error]').textContent = error.message; } }; return d;
}
