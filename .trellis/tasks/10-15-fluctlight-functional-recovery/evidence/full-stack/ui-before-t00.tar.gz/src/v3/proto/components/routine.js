import { esc, badge } from './controls.js';
import { Field, Button, KeyValueList } from './forms.js';

export function RoutineEditor({ slots, places }) {
  const options = [{ value: '', label: '选择地点' }, ...places.map(place => ({ value: place.id, label: place.name }))];
  return `<div class="stack" data-routine>${slots.map((slot, index) => `<div class="card" data-slot="${index}"><div class="grid g3">${Field({ label: '适用日', name: `day_${index}`, value: slot.day, type: 'select', options: ['每天', '工作日', '周末'] })}${Field({ label: '开始', name: `start_${index}`, value: slot.start, type: 'time' })}${Field({ label: '结束', name: `end_${index}`, value: slot.end, type: 'time' })}</div><div class="row" style="margin-top:8px">${Field({ label: '地点', name: `place_${index}`, value: slot.placeId, type: 'select', options })}${Field({ label: '活动', name: `activity_${index}`, value: slot.activity })}${Button({ label: '移除时段', tone: 'ghost danger', size: 'sm', attrs: { 'data-remove-slot': index } })}</div></div>`).join('')}</div>${Button({ label: '添加规律时段', attrs: { 'data-add-slot': true } })}`;
}
export function PositionSummary({ npc, placeName }) {
  const mode = npc.positionMode || '默认地点';
  return `${KeyValueList([['位置模式', esc(mode)], ['初始 / 默认地点', esc(placeName(npc.placeId))], ['生活规律', npc.routine?.length ? `${npc.routine.length} 个时段 ${badge('计划')}` : '尚未设置'], ['上次确认位置', npc.confirmedPlaceId ? `${esc(placeName(npc.confirmedPlaceId))} · ${esc(npc.confirmedAt)}` : '无确认记录']], { className: 'kv small' })}<p class="small muted">规律和默认地点不代表此刻在场；浏览此页不移动任何角色。</p>`;
}
